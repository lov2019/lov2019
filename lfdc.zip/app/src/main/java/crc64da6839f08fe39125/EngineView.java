package crc64da6839f08fe39125;

import android.content.Context;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.MotionEvent;
import java.util.ArrayList;
import mono.android.Runtime;
import mono.android.TypeManager;
import opentk_1_0.platform.android.AndroidGameView;

/* loaded from: classes.dex */
public class EngineView extends AndroidGameView {
    public static final String __md_methods = "n_onWindowFocusChanged:(Z)V:GetOnWindowFocusChanged_ZHandler\nn_onKeyDown:(ILandroid/view/KeyEvent;)Z:GetOnKeyDown_ILandroid_view_KeyEvent_Handler\nn_onKeyUp:(ILandroid/view/KeyEvent;)Z:GetOnKeyUp_ILandroid_view_KeyEvent_Handler\nn_onGenericMotionEvent:(Landroid/view/MotionEvent;)Z:GetOnGenericMotionEvent_Landroid_view_MotionEvent_Handler\nn_onTouchEvent:(Landroid/view/MotionEvent;)Z:GetOnTouchEvent_Landroid_view_MotionEvent_Handler\n";
    private ArrayList refList;

    static {
        Runtime.register("Engine.EngineView, Engine", EngineView.class, __md_methods);
    }

    public EngineView(Context context) {
        super(context);
        if (getClass() == EngineView.class) {
            TypeManager.Activate("Engine.EngineView, Engine", "Android.Content.Context, Mono.Android", this, new Object[]{context});
        }
    }

    private native boolean n_onGenericMotionEvent(MotionEvent motionEvent);

    private native boolean n_onKeyDown(int i, KeyEvent keyEvent);

    private native boolean n_onKeyUp(int i, KeyEvent keyEvent);

    private native boolean n_onTouchEvent(MotionEvent motionEvent);

    private native void n_onWindowFocusChanged(boolean z);

    @Override // opentk_1_0.platform.android.AndroidGameView, opentk_1_0.GameViewBase, mono.android.IGCUserPeer
    public void monodroidAddReference(Object obj) {
        if (this.refList == null) {
            this.refList = new ArrayList();
        }
        this.refList.add(obj);
    }

    @Override // opentk_1_0.platform.android.AndroidGameView, opentk_1_0.GameViewBase, mono.android.IGCUserPeer
    public void monodroidClearReferences() {
        ArrayList arrayList = this.refList;
        if (arrayList != null) {
            arrayList.clear();
        }
    }

    @Override // android.view.View
    public boolean onGenericMotionEvent(MotionEvent motionEvent) {
        return n_onGenericMotionEvent(motionEvent);
    }

    @Override // android.view.View, android.view.KeyEvent.Callback
    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        return n_onKeyDown(i, keyEvent);
    }

    @Override // android.view.View, android.view.KeyEvent.Callback
    public boolean onKeyUp(int i, KeyEvent keyEvent) {
        return n_onKeyUp(i, keyEvent);
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        return n_onTouchEvent(motionEvent);
    }

    @Override // android.view.View
    public void onWindowFocusChanged(boolean z) {
        n_onWindowFocusChanged(z);
    }

    public EngineView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        if (getClass() == EngineView.class) {
            TypeManager.Activate("Engine.EngineView, Engine", "Android.Content.Context, Mono.Android:Android.Util.IAttributeSet, Mono.Android", this, new Object[]{context, attributeSet});
        }
    }

    public EngineView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        if (getClass() == EngineView.class) {
            TypeManager.Activate("Engine.EngineView, Engine", "Android.Content.Context, Mono.Android:Android.Util.IAttributeSet, Mono.Android:System.Int32, mscorlib", this, new Object[]{context, attributeSet, Integer.valueOf(i)});
        }
    }
}
