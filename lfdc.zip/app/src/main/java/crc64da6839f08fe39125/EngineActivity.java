package crc64da6839f08fe39125;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import java.util.ArrayList;
import mono.android.IGCUserPeer;
import mono.android.Runtime;
import mono.android.TypeManager;

/* loaded from: classes.dex */
public class EngineActivity extends Activity implements IGCUserPeer {
    public static final String __md_methods = "n_onCreate:(Landroid/os/Bundle;)V:GetOnCreate_Landroid_os_Bundle_Handler\nn_onPause:()V:GetOnPauseHandler\nn_onResume:()V:GetOnResumeHandler\nn_onNewIntent:(Landroid/content/Intent;)V:GetOnNewIntent_Landroid_content_Intent_Handler\nn_onDestroy:()V:GetOnDestroyHandler\n";
    private ArrayList refList;

    static {
        Runtime.register("Engine.EngineActivity, Engine", EngineActivity.class, __md_methods);
    }

    public EngineActivity() {
        if (getClass() == EngineActivity.class) {
            TypeManager.Activate("Engine.EngineActivity, Engine", "", this, new Object[0]);
        }
    }

    private native void n_onCreate(Bundle bundle);

    private native void n_onDestroy();

    private native void n_onNewIntent(Intent intent);

    private native void n_onPause();

    private native void n_onResume();

    public void monodroidAddReference(Object obj) {
        if (this.refList == null) {
            this.refList = new ArrayList();
        }
        this.refList.add(obj);
    }

    public void monodroidClearReferences() {
        ArrayList arrayList = this.refList;
        if (arrayList != null) {
            arrayList.clear();
        }
    }

    @Override // android.app.Activity
    public void onCreate(Bundle bundle) {
        n_onCreate(bundle);
    }

    @Override // android.app.Activity
    public void onDestroy() {
        n_onDestroy();
    }

    @Override // android.app.Activity
    public void onNewIntent(Intent intent) {
        n_onNewIntent(intent);
    }

    @Override // android.app.Activity
    public void onPause() {
        n_onPause();
    }

    @Override // android.app.Activity
    public void onResume() {
        n_onResume();
    }
}
