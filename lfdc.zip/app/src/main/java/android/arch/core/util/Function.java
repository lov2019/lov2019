package android.arch.core.util;

/* loaded from: classes.dex */
public interface Function {
}
