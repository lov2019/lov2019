package android.arch.core.internal;

/* loaded from: classes.dex */
public abstract /* synthetic */ class SafeIterableMap$$ExternalSyntheticOutline0 {
    public static StringBuilder m(String str) {
        StringBuilder sb = new StringBuilder();
        sb.append(str);
        return sb;
    }
}
