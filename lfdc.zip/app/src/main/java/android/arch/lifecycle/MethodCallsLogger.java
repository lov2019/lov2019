package android.arch.lifecycle;

import android.support.annotation.RestrictTo;
import java.util.HashMap;

@RestrictTo
/* loaded from: classes.dex */
public class MethodCallsLogger {
    private HashMap mCalledMethods = new HashMap();

    @RestrictTo
    public boolean approveCall(String str, int i) {
        Integer num = (Integer) this.mCalledMethods.get(str);
        int intValue = num != null ? num.intValue() : 0;
        boolean z = (intValue & i) != 0;
        this.mCalledMethods.put(str, Integer.valueOf(i | intValue));
        return !z;
    }
}
