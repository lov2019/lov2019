package android.arch.lifecycle;

/* loaded from: classes.dex */
public interface LifecycleOwner {
    Lifecycle getLifecycle();
}
