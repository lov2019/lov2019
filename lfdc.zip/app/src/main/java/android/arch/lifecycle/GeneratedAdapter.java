package android.arch.lifecycle;

import android.support.annotation.RestrictTo;

@RestrictTo
/* loaded from: classes.dex */
public interface GeneratedAdapter {
    void callMethods();
}
