package android.support.v4.widget;

import android.support.annotation.RestrictTo;

@RestrictTo
/* loaded from: classes.dex */
public interface AutoSizeableTextView {
    int getAutoSizeMaxTextSize();

    int getAutoSizeMinTextSize();

    int getAutoSizeStepGranularity();

    int[] getAutoSizeTextAvailableSizes();

    int getAutoSizeTextType();

    void setAutoSizeTextTypeUniformWithConfiguration();

    void setAutoSizeTextTypeUniformWithPresetSizes();

    void setAutoSizeTextTypeWithDefaults();
}
