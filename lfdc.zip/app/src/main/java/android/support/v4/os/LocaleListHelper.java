package android.support.v4.os;

import android.arch.core.internal.SafeIterableMap$$ExternalSyntheticOutline0;
import java.util.HashSet;
import java.util.Locale;

/* loaded from: classes.dex */
final class LocaleListHelper {
    private static final Locale LOCALE_AR_XB;
    private static final Locale LOCALE_EN_XA;
    private static final Locale[] sEmptyList = new Locale[0];
    private final Locale[] mList;
    private final String mStringRepresentation;

    static {
        new LocaleListHelper(new Locale[0]);
        LOCALE_EN_XA = new Locale("en", "XA");
        LOCALE_AR_XB = new Locale("ar", "XB");
        LocaleHelper.forLanguageTag("en-Latn");
    }

    LocaleListHelper(Locale... localeArr) {
        if (localeArr.length == 0) {
            this.mList = sEmptyList;
            this.mStringRepresentation = "";
            return;
        }
        Locale[] localeArr2 = new Locale[localeArr.length];
        HashSet hashSet = new HashSet();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < localeArr.length; i++) {
            Locale locale = localeArr[i];
            if (locale == null) {
                throw new NullPointerException("list[" + i + "] is null");
            }
            if (hashSet.contains(locale)) {
                throw new IllegalArgumentException("list[" + i + "] is a repetition");
            }
            Locale locale2 = (Locale) locale.clone();
            localeArr2[i] = locale2;
            StringBuilder sb2 = new StringBuilder();
            sb2.append(locale2.getLanguage());
            String country = locale2.getCountry();
            if (country != null && !country.isEmpty()) {
                sb2.append("-");
                sb2.append(locale2.getCountry());
            }
            sb.append(sb2.toString());
            if (i < localeArr.length - 1) {
                sb.append(',');
            }
            hashSet.add(locale2);
        }
        this.mList = localeArr2;
        this.mStringRepresentation = sb.toString();
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof LocaleListHelper)) {
            return false;
        }
        Locale[] localeArr = ((LocaleListHelper) obj).mList;
        if (this.mList.length != localeArr.length) {
            return false;
        }
        int i = 0;
        while (true) {
            Locale[] localeArr2 = this.mList;
            if (i >= localeArr2.length) {
                return true;
            }
            if (!localeArr2[i].equals(localeArr[i])) {
                return false;
            }
            i++;
        }
    }

    final Locale get(int i) {
        if (i >= 0) {
            Locale[] localeArr = this.mList;
            if (i < localeArr.length) {
                return localeArr[i];
            }
        }
        return null;
    }

    /* JADX WARN: Code restructure failed: missing block: B:36:0x009f, code lost:
    
        if (r8.equals(r7.getCountry()) == false) goto L52;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:42:0x00b7 A[LOOP:1: B:10:0x002f->B:42:0x00b7, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:43:0x00be A[EDGE_INSN: B:43:0x00be->B:44:0x00be BREAK  A[LOOP:1: B:10:0x002f->B:42:0x00b7], SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r7v2 */
    /* JADX WARN: Type inference failed for: r7v3 */
    /* JADX WARN: Type inference failed for: r7v4 */
    /* JADX WARN: Type inference failed for: r7v9 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    final java.util.Locale getFirstMatch(java.lang.String[] r12) {
        /*
            r11 = this;
            java.util.List r12 = java.util.Arrays.asList(r12)
            java.util.Locale[] r0 = r11.mList
            int r1 = r0.length
            r2 = -1
            r3 = 1
            r4 = 0
            if (r1 != r3) goto Le
            goto Lca
        Le:
            int r0 = r0.length
            if (r0 != 0) goto L14
            r4 = -1
            goto Lca
        L14:
            java.util.Iterator r12 = r12.iterator()
            r0 = 2147483647(0x7fffffff, float:NaN)
            r1 = 2147483647(0x7fffffff, float:NaN)
        L1e:
            boolean r5 = r12.hasNext()
            if (r5 == 0) goto Lc6
            java.lang.Object r5 = r12.next()
            java.lang.String r5 = (java.lang.String) r5
            java.util.Locale r5 = android.support.v4.os.LocaleHelper.forLanguageTag(r5)
            r6 = 0
        L2f:
            java.util.Locale[] r7 = r11.mList
            int r8 = r7.length
            if (r6 >= r8) goto Lbb
            r7 = r7[r6]
            boolean r8 = r5.equals(r7)
            if (r8 == 0) goto L3e
            goto La1
        L3e:
            java.lang.String r8 = r5.getLanguage()
            java.lang.String r9 = r7.getLanguage()
            boolean r8 = r8.equals(r9)
            if (r8 != 0) goto L4e
            goto Lb3
        L4e:
            java.util.Locale r8 = android.support.v4.os.LocaleListHelper.LOCALE_EN_XA
            boolean r9 = r8.equals(r5)
            if (r9 != 0) goto L61
            java.util.Locale r9 = android.support.v4.os.LocaleListHelper.LOCALE_AR_XB
            boolean r9 = r9.equals(r5)
            if (r9 == 0) goto L5f
            goto L61
        L5f:
            r9 = 0
            goto L62
        L61:
            r9 = 1
        L62:
            if (r9 != 0) goto Lb3
            boolean r8 = r8.equals(r7)
            if (r8 != 0) goto L75
            java.util.Locale r8 = android.support.v4.os.LocaleListHelper.LOCALE_AR_XB
            boolean r8 = r8.equals(r7)
            if (r8 == 0) goto L73
            goto L75
        L73:
            r8 = 0
            goto L76
        L75:
            r8 = 1
        L76:
            if (r8 == 0) goto L79
            goto Lb3
        L79:
            java.lang.String r8 = r5.getScript()
            boolean r9 = r8.isEmpty()
            java.lang.String r10 = ""
            if (r9 != 0) goto L86
            goto L87
        L86:
            r8 = r10
        L87:
            boolean r9 = r8.isEmpty()
            if (r9 == 0) goto La3
            java.lang.String r8 = r5.getCountry()
            boolean r9 = r8.isEmpty()
            if (r9 != 0) goto La1
            java.lang.String r7 = r7.getCountry()
            boolean r7 = r8.equals(r7)
            if (r7 == 0) goto Lb3
        La1:
            r7 = 1
            goto Lb4
        La3:
            java.lang.String r7 = r7.getScript()
            boolean r9 = r7.isEmpty()
            if (r9 != 0) goto Lae
            r10 = r7
        Lae:
            boolean r7 = r8.equals(r10)
            goto Lb4
        Lb3:
            r7 = 0
        Lb4:
            if (r7 <= 0) goto Lb7
            goto Lbe
        Lb7:
            int r6 = r6 + 1
            goto L2f
        Lbb:
            r6 = 2147483647(0x7fffffff, float:NaN)
        Lbe:
            if (r6 != 0) goto Lc1
            goto Lca
        Lc1:
            if (r6 >= r1) goto L1e
            r1 = r6
            goto L1e
        Lc6:
            if (r1 != r0) goto Lc9
            goto Lca
        Lc9:
            r4 = r1
        Lca:
            if (r4 != r2) goto Lce
            r12 = 0
            goto Ld2
        Lce:
            java.util.Locale[] r12 = r11.mList
            r12 = r12[r4]
        Ld2:
            return r12
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.os.LocaleListHelper.getFirstMatch(java.lang.String[]):java.util.Locale");
    }

    public final int hashCode() {
        int i = 1;
        int i2 = 0;
        while (true) {
            Locale[] localeArr = this.mList;
            if (i2 >= localeArr.length) {
                return i;
            }
            i = (i * 31) + localeArr[i2].hashCode();
            i2++;
        }
    }

    final int indexOf(Locale locale) {
        int i = 0;
        while (true) {
            Locale[] localeArr = this.mList;
            if (i >= localeArr.length) {
                return -1;
            }
            if (localeArr[i].equals(locale)) {
                return i;
            }
            i++;
        }
    }

    final boolean isEmpty() {
        return this.mList.length == 0;
    }

    final int size() {
        return this.mList.length;
    }

    final String toLanguageTags() {
        return this.mStringRepresentation;
    }

    public final String toString() {
        StringBuilder m = SafeIterableMap$$ExternalSyntheticOutline0.m("[");
        int i = 0;
        while (true) {
            Locale[] localeArr = this.mList;
            if (i >= localeArr.length) {
                m.append("]");
                return m.toString();
            }
            m.append(localeArr[i]);
            if (i < this.mList.length - 1) {
                m.append(',');
            }
            i++;
        }
    }
}
