package android.support.v4.util;

import android.arch.core.internal.SafeIterableMap$$ExternalSyntheticOutline0;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

/* loaded from: classes.dex */
public class Pair {
    public final Object first;
    public final Object second;

    public Pair(@Nullable Object obj, @Nullable Object obj2) {
        this.first = obj;
        this.second = obj2;
    }

    @NonNull
    public static Pair create(@Nullable Object obj, @Nullable Object obj2) {
        return new Pair(obj, obj2);
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof Pair)) {
            return false;
        }
        Pair pair = (Pair) obj;
        return ObjectsCompat.equals(pair.first, this.first) && ObjectsCompat.equals(pair.second, this.second);
    }

    public final int hashCode() {
        Object obj = this.first;
        int hashCode = obj == null ? 0 : obj.hashCode();
        Object obj2 = this.second;
        return hashCode ^ (obj2 != null ? obj2.hashCode() : 0);
    }

    public final String toString() {
        StringBuilder m = SafeIterableMap$$ExternalSyntheticOutline0.m("Pair{");
        m.append(String.valueOf(this.first));
        m.append(" ");
        m.append(String.valueOf(this.second));
        m.append("}");
        return m.toString();
    }
}
