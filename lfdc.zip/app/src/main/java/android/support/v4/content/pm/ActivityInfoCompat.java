package android.support.v4.content.pm;

@Deprecated
/* loaded from: classes.dex */
public final class ActivityInfoCompat {
    private ActivityInfoCompat() {
    }
}
