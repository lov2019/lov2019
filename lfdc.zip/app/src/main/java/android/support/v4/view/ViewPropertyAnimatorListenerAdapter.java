package android.support.v4.view;

import android.view.View;

/* loaded from: classes.dex */
public class ViewPropertyAnimatorListenerAdapter implements ViewPropertyAnimatorListener {
    @Override // android.support.v4.view.ViewPropertyAnimatorListener
    public void onAnimationCancel(View view) {
    }

    @Override // android.support.v4.view.ViewPropertyAnimatorListener
    public void onAnimationEnd(View view) {
    }

    @Override // android.support.v4.view.ViewPropertyAnimatorListener
    public void onAnimationStart(View view) {
    }
}
