package android.support.v4.widget;

import android.support.annotation.RestrictTo;

@RestrictTo
/* loaded from: classes.dex */
public interface TintableImageSourceView {
}
