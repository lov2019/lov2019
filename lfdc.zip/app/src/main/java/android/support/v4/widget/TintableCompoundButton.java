package android.support.v4.widget;

/* loaded from: classes.dex */
public interface TintableCompoundButton {
}
