package android.support.v4.hardware.fingerprint;

import android.content.Context;
import android.hardware.fingerprint.FingerprintManager;
import android.os.Build;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresPermission;
import android.support.v4.os.CancellationSignal;
import java.security.Signature;
import javax.crypto.Cipher;
import javax.crypto.Mac;

/* loaded from: classes.dex */
public final class FingerprintManagerCompat {
    private final Context mContext;

    public abstract class AuthenticationCallback {
        public void onAuthenticationError(int i, CharSequence charSequence) {
        }

        public void onAuthenticationFailed() {
        }

        public void onAuthenticationHelp(int i, CharSequence charSequence) {
        }

        public void onAuthenticationSucceeded(AuthenticationResult authenticationResult) {
        }
    }

    public final class AuthenticationResult {
        private final CryptoObject mCryptoObject;

        public AuthenticationResult(CryptoObject cryptoObject) {
            this.mCryptoObject = cryptoObject;
        }

        public CryptoObject getCryptoObject() {
            return this.mCryptoObject;
        }
    }

    private FingerprintManagerCompat(Context context) {
        this.mContext = context;
    }

    @NonNull
    public static FingerprintManagerCompat from(@NonNull Context context) {
        return new FingerprintManagerCompat(context);
    }

    private static FingerprintManager getFingerprintManagerOrNull(Context context) {
        if (context.getPackageManager().hasSystemFeature("android.hardware.fingerprint")) {
            return (FingerprintManager) context.getSystemService(FingerprintManager.class);
        }
        return null;
    }

    @RequiresPermission
    public void authenticate(@Nullable CryptoObject cryptoObject, int i, @Nullable CancellationSignal cancellationSignal, @NonNull final AuthenticationCallback authenticationCallback, @Nullable Handler handler) {
        FingerprintManager fingerprintManagerOrNull;
        FingerprintManager.CryptoObject cryptoObject2;
        FingerprintManager.CryptoObject cryptoObject3;
        if (Build.VERSION.SDK_INT < 23 || (fingerprintManagerOrNull = getFingerprintManagerOrNull(this.mContext)) == null) {
            return;
        }
        FingerprintManager.CryptoObject cryptoObject4 = null;
        android.os.CancellationSignal cancellationSignal2 = cancellationSignal != null ? (android.os.CancellationSignal) cancellationSignal.getCancellationSignalObject() : null;
        if (cryptoObject != null) {
            if (cryptoObject.getCipher() != null) {
                cryptoObject2 = new FingerprintManager.CryptoObject(cryptoObject.getCipher());
            } else if (cryptoObject.getSignature() != null) {
                cryptoObject2 = new FingerprintManager.CryptoObject(cryptoObject.getSignature());
            } else if (cryptoObject.getMac() != null) {
                cryptoObject4 = new FingerprintManager.CryptoObject(cryptoObject.getMac());
            }
            cryptoObject3 = cryptoObject2;
            fingerprintManagerOrNull.authenticate(cryptoObject3, cancellationSignal2, i, new FingerprintManager.AuthenticationCallback() { // from class: android.support.v4.hardware.fingerprint.FingerprintManagerCompat.1
                @Override // android.hardware.fingerprint.FingerprintManager.AuthenticationCallback
                public final void onAuthenticationError(int i2, CharSequence charSequence) {
                    AuthenticationCallback.this.onAuthenticationError(i2, charSequence);
                }

                @Override // android.hardware.fingerprint.FingerprintManager.AuthenticationCallback
                public final void onAuthenticationFailed() {
                    AuthenticationCallback.this.onAuthenticationFailed();
                }

                @Override // android.hardware.fingerprint.FingerprintManager.AuthenticationCallback
                public final void onAuthenticationHelp(int i2, CharSequence charSequence) {
                    AuthenticationCallback.this.onAuthenticationHelp(i2, charSequence);
                }

                @Override // android.hardware.fingerprint.FingerprintManager.AuthenticationCallback
                public final void onAuthenticationSucceeded(FingerprintManager.AuthenticationResult authenticationResult) {
                    AuthenticationCallback authenticationCallback2 = AuthenticationCallback.this;
                    FingerprintManager.CryptoObject cryptoObject5 = authenticationResult.getCryptoObject();
                    CryptoObject cryptoObject6 = null;
                    if (cryptoObject5 != null) {
                        if (cryptoObject5.getCipher() != null) {
                            cryptoObject6 = new CryptoObject(cryptoObject5.getCipher());
                        } else if (cryptoObject5.getSignature() != null) {
                            cryptoObject6 = new CryptoObject(cryptoObject5.getSignature());
                        } else if (cryptoObject5.getMac() != null) {
                            cryptoObject6 = new CryptoObject(cryptoObject5.getMac());
                        }
                    }
                    authenticationCallback2.onAuthenticationSucceeded(new AuthenticationResult(cryptoObject6));
                }
            }, handler);
        }
        cryptoObject3 = cryptoObject4;
        fingerprintManagerOrNull.authenticate(cryptoObject3, cancellationSignal2, i, new FingerprintManager.AuthenticationCallback() { // from class: android.support.v4.hardware.fingerprint.FingerprintManagerCompat.1
            @Override // android.hardware.fingerprint.FingerprintManager.AuthenticationCallback
            public final void onAuthenticationError(int i2, CharSequence charSequence) {
                AuthenticationCallback.this.onAuthenticationError(i2, charSequence);
            }

            @Override // android.hardware.fingerprint.FingerprintManager.AuthenticationCallback
            public final void onAuthenticationFailed() {
                AuthenticationCallback.this.onAuthenticationFailed();
            }

            @Override // android.hardware.fingerprint.FingerprintManager.AuthenticationCallback
            public final void onAuthenticationHelp(int i2, CharSequence charSequence) {
                AuthenticationCallback.this.onAuthenticationHelp(i2, charSequence);
            }

            @Override // android.hardware.fingerprint.FingerprintManager.AuthenticationCallback
            public final void onAuthenticationSucceeded(FingerprintManager.AuthenticationResult authenticationResult) {
                AuthenticationCallback authenticationCallback2 = AuthenticationCallback.this;
                FingerprintManager.CryptoObject cryptoObject5 = authenticationResult.getCryptoObject();
                CryptoObject cryptoObject6 = null;
                if (cryptoObject5 != null) {
                    if (cryptoObject5.getCipher() != null) {
                        cryptoObject6 = new CryptoObject(cryptoObject5.getCipher());
                    } else if (cryptoObject5.getSignature() != null) {
                        cryptoObject6 = new CryptoObject(cryptoObject5.getSignature());
                    } else if (cryptoObject5.getMac() != null) {
                        cryptoObject6 = new CryptoObject(cryptoObject5.getMac());
                    }
                }
                authenticationCallback2.onAuthenticationSucceeded(new AuthenticationResult(cryptoObject6));
            }
        }, handler);
    }

    @RequiresPermission
    public boolean hasEnrolledFingerprints() {
        FingerprintManager fingerprintManagerOrNull;
        return Build.VERSION.SDK_INT >= 23 && (fingerprintManagerOrNull = getFingerprintManagerOrNull(this.mContext)) != null && fingerprintManagerOrNull.hasEnrolledFingerprints();
    }

    @RequiresPermission
    public boolean isHardwareDetected() {
        FingerprintManager fingerprintManagerOrNull;
        return Build.VERSION.SDK_INT >= 23 && (fingerprintManagerOrNull = getFingerprintManagerOrNull(this.mContext)) != null && fingerprintManagerOrNull.isHardwareDetected();
    }

    public class CryptoObject {
        private final Cipher mCipher;
        private final Mac mMac;
        private final Signature mSignature;

        public CryptoObject(@NonNull Signature signature) {
            this.mSignature = signature;
            this.mCipher = null;
            this.mMac = null;
        }

        @Nullable
        public Cipher getCipher() {
            return this.mCipher;
        }

        @Nullable
        public Mac getMac() {
            return this.mMac;
        }

        @Nullable
        public Signature getSignature() {
            return this.mSignature;
        }

        public CryptoObject(@NonNull Cipher cipher) {
            this.mCipher = cipher;
            this.mSignature = null;
            this.mMac = null;
        }

        public CryptoObject(@NonNull Mac mac) {
            this.mMac = mac;
            this.mCipher = null;
            this.mSignature = null;
        }
    }
}
