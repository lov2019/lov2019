package android.support.v4.os;

@Deprecated
/* loaded from: classes.dex */
public interface ParcelableCompatCreatorCallbacks {
    Object createFromParcel();

    Object[] newArray();
}
