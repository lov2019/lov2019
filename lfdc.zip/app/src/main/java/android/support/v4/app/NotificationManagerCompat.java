package android.support.v4.app;

import android.app.AppOpsManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.arch.core.internal.SafeIterableMap$$ExternalSyntheticOutline0;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.ApplicationInfo;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.DeadObjectException;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Message;
import android.os.RemoteException;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.INotificationSideChannel;
import android.util.Log;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/* loaded from: classes.dex */
public final class NotificationManagerCompat {
    private static String sEnabledNotificationListeners;
    private static SideChannelManager sSideChannelManager;
    private final Context mContext;
    private final NotificationManager mNotificationManager;
    private static final Object sEnabledNotificationListenersLock = new Object();
    private static HashSet sEnabledNotificationListenerPackages = new HashSet();
    private static final Object sLock = new Object();

    final class NotifyTask implements Task {
        final int id;
        final Notification notif;
        final String packageName;
        final String tag;

        NotifyTask(String str, int i, String str2, Notification notification) {
            this.packageName = str;
            this.id = i;
            this.tag = str2;
            this.notif = notification;
        }

        @Override // android.support.v4.app.NotificationManagerCompat.Task
        public final void send(INotificationSideChannel iNotificationSideChannel) {
            iNotificationSideChannel.notify(this.packageName, this.id, this.tag, this.notif);
        }

        public final String toString() {
            return "NotifyTask[packageName:" + this.packageName + ", id:" + this.id + ", tag:" + this.tag + "]";
        }
    }

    final class ServiceConnectedEvent {
        final ComponentName componentName;
        final IBinder iBinder;

        ServiceConnectedEvent(ComponentName componentName, IBinder iBinder) {
            this.componentName = componentName;
            this.iBinder = iBinder;
        }
    }

    final class SideChannelManager implements Handler.Callback, ServiceConnection {
        private final Context mContext;
        private final Handler mHandler;
        private final HashMap mRecordMap = new HashMap();
        private Set mCachedEnabledPackages = new HashSet();

        final class ListenerRecord {
            final ComponentName componentName;
            INotificationSideChannel service;
            boolean bound = false;
            ArrayDeque taskQueue = new ArrayDeque();
            int retryCount = 0;

            ListenerRecord(ComponentName componentName) {
                this.componentName = componentName;
            }
        }

        SideChannelManager(Context context) {
            this.mContext = context;
            HandlerThread handlerThread = new HandlerThread("NotificationManagerCompat");
            handlerThread.start();
            this.mHandler = new Handler(handlerThread.getLooper(), this);
        }

        private void processListenerQueue(ListenerRecord listenerRecord) {
            boolean z;
            if (Log.isLoggable("NotifManCompat", 3)) {
                StringBuilder m = SafeIterableMap$$ExternalSyntheticOutline0.m("Processing component ");
                m.append(listenerRecord.componentName);
                m.append(", ");
                m.append(listenerRecord.taskQueue.size());
                m.append(" queued tasks");
                Log.d("NotifManCompat", m.toString());
            }
            if (listenerRecord.taskQueue.isEmpty()) {
                return;
            }
            if (listenerRecord.bound) {
                z = true;
            } else {
                boolean bindService = this.mContext.bindService(new Intent("android.support.BIND_NOTIFICATION_SIDE_CHANNEL").setComponent(listenerRecord.componentName), this, 33);
                listenerRecord.bound = bindService;
                if (bindService) {
                    listenerRecord.retryCount = 0;
                } else {
                    StringBuilder m2 = SafeIterableMap$$ExternalSyntheticOutline0.m("Unable to bind to listener ");
                    m2.append(listenerRecord.componentName);
                    Log.w("NotifManCompat", m2.toString());
                    this.mContext.unbindService(this);
                }
                z = listenerRecord.bound;
            }
            if (!z || listenerRecord.service == null) {
                scheduleListenerRetry(listenerRecord);
                return;
            }
            while (true) {
                Task task = (Task) listenerRecord.taskQueue.peek();
                if (task == null) {
                    break;
                }
                try {
                    if (Log.isLoggable("NotifManCompat", 3)) {
                        Log.d("NotifManCompat", "Sending task " + task);
                    }
                    task.send(listenerRecord.service);
                    listenerRecord.taskQueue.remove();
                } catch (DeadObjectException unused) {
                    if (Log.isLoggable("NotifManCompat", 3)) {
                        StringBuilder m3 = SafeIterableMap$$ExternalSyntheticOutline0.m("Remote service has died: ");
                        m3.append(listenerRecord.componentName);
                        Log.d("NotifManCompat", m3.toString());
                    }
                } catch (RemoteException e) {
                    StringBuilder m4 = SafeIterableMap$$ExternalSyntheticOutline0.m("RemoteException communicating with ");
                    m4.append(listenerRecord.componentName);
                    Log.w("NotifManCompat", m4.toString(), e);
                }
            }
            if (listenerRecord.taskQueue.isEmpty()) {
                return;
            }
            scheduleListenerRetry(listenerRecord);
        }

        private void scheduleListenerRetry(ListenerRecord listenerRecord) {
            if (this.mHandler.hasMessages(3, listenerRecord.componentName)) {
                return;
            }
            int i = listenerRecord.retryCount + 1;
            listenerRecord.retryCount = i;
            if (i > 6) {
                StringBuilder m = SafeIterableMap$$ExternalSyntheticOutline0.m("Giving up on delivering ");
                m.append(listenerRecord.taskQueue.size());
                m.append(" tasks to ");
                m.append(listenerRecord.componentName);
                m.append(" after ");
                m.append(listenerRecord.retryCount);
                m.append(" retries");
                Log.w("NotifManCompat", m.toString());
                listenerRecord.taskQueue.clear();
                return;
            }
            int i2 = (1 << (i - 1)) * 1000;
            if (Log.isLoggable("NotifManCompat", 3)) {
                Log.d("NotifManCompat", "Scheduling retry for " + i2 + " ms");
            }
            this.mHandler.sendMessageDelayed(this.mHandler.obtainMessage(3, listenerRecord.componentName), i2);
        }

        @Override // android.os.Handler.Callback
        public final boolean handleMessage(Message message) {
            int i = message.what;
            if (i != 0) {
                if (i == 1) {
                    ServiceConnectedEvent serviceConnectedEvent = (ServiceConnectedEvent) message.obj;
                    ComponentName componentName = serviceConnectedEvent.componentName;
                    IBinder iBinder = serviceConnectedEvent.iBinder;
                    ListenerRecord listenerRecord = (ListenerRecord) this.mRecordMap.get(componentName);
                    if (listenerRecord != null) {
                        listenerRecord.service = INotificationSideChannel.Stub.asInterface(iBinder);
                        listenerRecord.retryCount = 0;
                        processListenerQueue(listenerRecord);
                    }
                    return true;
                }
                if (i != 2) {
                    if (i != 3) {
                        return false;
                    }
                    ListenerRecord listenerRecord2 = (ListenerRecord) this.mRecordMap.get((ComponentName) message.obj);
                    if (listenerRecord2 != null) {
                        processListenerQueue(listenerRecord2);
                    }
                    return true;
                }
                ListenerRecord listenerRecord3 = (ListenerRecord) this.mRecordMap.get((ComponentName) message.obj);
                if (listenerRecord3 != null) {
                    if (listenerRecord3.bound) {
                        this.mContext.unbindService(this);
                        listenerRecord3.bound = false;
                    }
                    listenerRecord3.service = null;
                }
                return true;
            }
            Task task = (Task) message.obj;
            Set enabledListenerPackages = NotificationManagerCompat.getEnabledListenerPackages(this.mContext);
            if (!enabledListenerPackages.equals(this.mCachedEnabledPackages)) {
                this.mCachedEnabledPackages = enabledListenerPackages;
                List<ResolveInfo> queryIntentServices = this.mContext.getPackageManager().queryIntentServices(new Intent().setAction("android.support.BIND_NOTIFICATION_SIDE_CHANNEL"), 0);
                HashSet hashSet = new HashSet();
                for (ResolveInfo resolveInfo : queryIntentServices) {
                    if (enabledListenerPackages.contains(resolveInfo.serviceInfo.packageName)) {
                        ServiceInfo serviceInfo = resolveInfo.serviceInfo;
                        ComponentName componentName2 = new ComponentName(serviceInfo.packageName, serviceInfo.name);
                        if (resolveInfo.serviceInfo.permission != null) {
                            Log.w("NotifManCompat", "Permission present on component " + componentName2 + ", not adding listener record.");
                        } else {
                            hashSet.add(componentName2);
                        }
                    }
                }
                Iterator it = hashSet.iterator();
                while (it.hasNext()) {
                    ComponentName componentName3 = (ComponentName) it.next();
                    if (!this.mRecordMap.containsKey(componentName3)) {
                        if (Log.isLoggable("NotifManCompat", 3)) {
                            Log.d("NotifManCompat", "Adding listener record for " + componentName3);
                        }
                        this.mRecordMap.put(componentName3, new ListenerRecord(componentName3));
                    }
                }
                Iterator it2 = this.mRecordMap.entrySet().iterator();
                while (it2.hasNext()) {
                    Map.Entry entry = (Map.Entry) it2.next();
                    if (!hashSet.contains(entry.getKey())) {
                        if (Log.isLoggable("NotifManCompat", 3)) {
                            StringBuilder m = SafeIterableMap$$ExternalSyntheticOutline0.m("Removing listener record for ");
                            m.append(entry.getKey());
                            Log.d("NotifManCompat", m.toString());
                        }
                        ListenerRecord listenerRecord4 = (ListenerRecord) entry.getValue();
                        if (listenerRecord4.bound) {
                            this.mContext.unbindService(this);
                            listenerRecord4.bound = false;
                        }
                        listenerRecord4.service = null;
                        it2.remove();
                    }
                }
            }
            for (ListenerRecord listenerRecord5 : this.mRecordMap.values()) {
                listenerRecord5.taskQueue.add(task);
                processListenerQueue(listenerRecord5);
            }
            return true;
        }

        @Override // android.content.ServiceConnection
        public final void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            if (Log.isLoggable("NotifManCompat", 3)) {
                Log.d("NotifManCompat", "Connected to service " + componentName);
            }
            this.mHandler.obtainMessage(1, new ServiceConnectedEvent(componentName, iBinder)).sendToTarget();
        }

        @Override // android.content.ServiceConnection
        public final void onServiceDisconnected(ComponentName componentName) {
            if (Log.isLoggable("NotifManCompat", 3)) {
                Log.d("NotifManCompat", "Disconnected from service " + componentName);
            }
            this.mHandler.obtainMessage(2, componentName).sendToTarget();
        }

        public final void queueTask(NotifyTask notifyTask) {
            this.mHandler.obtainMessage(0, notifyTask).sendToTarget();
        }
    }

    interface Task {
        void send(INotificationSideChannel iNotificationSideChannel);
    }

    private NotificationManagerCompat(Context context) {
        this.mContext = context;
        this.mNotificationManager = (NotificationManager) context.getSystemService("notification");
    }

    @NonNull
    public static NotificationManagerCompat from(@NonNull Context context) {
        return new NotificationManagerCompat(context);
    }

    @NonNull
    public static Set getEnabledListenerPackages(@NonNull Context context) {
        HashSet hashSet;
        String string = Settings.Secure.getString(context.getContentResolver(), "enabled_notification_listeners");
        synchronized (sEnabledNotificationListenersLock) {
            if (string != null) {
                if (!string.equals(sEnabledNotificationListeners)) {
                    String[] split = string.split(":", -1);
                    HashSet hashSet2 = new HashSet(split.length);
                    for (String str : split) {
                        ComponentName unflattenFromString = ComponentName.unflattenFromString(str);
                        if (unflattenFromString != null) {
                            hashSet2.add(unflattenFromString.getPackageName());
                        }
                    }
                    sEnabledNotificationListenerPackages = hashSet2;
                    sEnabledNotificationListeners = string;
                }
            }
            hashSet = sEnabledNotificationListenerPackages;
        }
        return hashSet;
    }

    public boolean areNotificationsEnabled() {
        if (Build.VERSION.SDK_INT >= 24) {
            return this.mNotificationManager.areNotificationsEnabled();
        }
        AppOpsManager appOpsManager = (AppOpsManager) this.mContext.getSystemService("appops");
        ApplicationInfo applicationInfo = this.mContext.getApplicationInfo();
        String packageName = this.mContext.getApplicationContext().getPackageName();
        int i = applicationInfo.uid;
        try {
            Class<?> cls = Class.forName(AppOpsManager.class.getName());
            Class<?> cls2 = Integer.TYPE;
            return ((Integer) cls.getMethod("checkOpNoThrow", cls2, cls2, String.class).invoke(appOpsManager, Integer.valueOf(((Integer) cls.getDeclaredField("OP_POST_NOTIFICATION").get(Integer.class)).intValue()), Integer.valueOf(i), packageName)).intValue() == 0;
        } catch (ClassNotFoundException | IllegalAccessException | NoSuchFieldException | NoSuchMethodException | RuntimeException | InvocationTargetException unused) {
            return true;
        }
    }

    public void cancel(int i) {
        cancel(null, i);
    }

    public void cancelAll() {
        this.mNotificationManager.cancelAll();
    }

    public int getImportance() {
        if (Build.VERSION.SDK_INT >= 24) {
            return this.mNotificationManager.getImportance();
        }
        return -1000;
    }

    public void notify(int i, @NonNull Notification notification) {
        notify(null, i, notification);
    }

    public void cancel(@Nullable String str, int i) {
        this.mNotificationManager.cancel(str, i);
    }

    public void notify(@Nullable String str, int i, @NonNull Notification notification) {
        Bundle extras = NotificationCompat.getExtras(notification);
        if (!(extras != null && extras.getBoolean("android.support.useSideChannel"))) {
            this.mNotificationManager.notify(str, i, notification);
            return;
        }
        NotifyTask notifyTask = new NotifyTask(this.mContext.getPackageName(), i, str, notification);
        synchronized (sLock) {
            if (sSideChannelManager == null) {
                sSideChannelManager = new SideChannelManager(this.mContext.getApplicationContext());
            }
            sSideChannelManager.queueTask(notifyTask);
        }
        this.mNotificationManager.cancel(str, i);
    }
}
