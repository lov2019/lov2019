package android.support.v4.text;

import android.text.SpannableStringBuilder;
import java.util.Locale;

/* loaded from: classes.dex */
public final class BidiFormatter {
    static final BidiFormatter DEFAULT_LTR_INSTANCE;
    static final BidiFormatter DEFAULT_RTL_INSTANCE;
    static final TextDirectionHeuristicCompat DEFAULT_TEXT_DIRECTION_HEURISTIC;
    private static final String LRM_STRING;
    private static final String RLM_STRING;
    private final TextDirectionHeuristicCompat mDefaultTextDirectionHeuristicCompat;
    private final int mFlags;
    private final boolean mIsRtlContext;

    final class DirectionalityEstimator {
        private static final byte[] DIR_TYPE_CACHE = new byte[1792];
        private int charIndex;
        private char lastChar;
        private final int length;
        private final CharSequence text;

        static {
            for (int i = 0; i < 1792; i++) {
                DIR_TYPE_CACHE[i] = Character.getDirectionality(i);
            }
        }

        DirectionalityEstimator(CharSequence charSequence) {
            this.text = charSequence;
            this.length = charSequence.length();
        }

        final byte dirTypeBackward() {
            char charAt = this.text.charAt(this.charIndex - 1);
            this.lastChar = charAt;
            if (Character.isLowSurrogate(charAt)) {
                int codePointBefore = Character.codePointBefore(this.text, this.charIndex);
                this.charIndex -= Character.charCount(codePointBefore);
                return Character.getDirectionality(codePointBefore);
            }
            this.charIndex--;
            char c = this.lastChar;
            return c < 1792 ? DIR_TYPE_CACHE[c] : Character.getDirectionality(c);
        }

        /* JADX WARN: Code restructure failed: missing block: B:45:0x006b, code lost:
        
            if (r3 != 0) goto L31;
         */
        /* JADX WARN: Code restructure failed: missing block: B:46:0x006d, code lost:
        
            return 0;
         */
        /* JADX WARN: Code restructure failed: missing block: B:47:0x006e, code lost:
        
            if (r4 == 0) goto L33;
         */
        /* JADX WARN: Code restructure failed: missing block: B:48:0x0070, code lost:
        
            return r4;
         */
        /* JADX WARN: Code restructure failed: missing block: B:50:0x0073, code lost:
        
            if (r9.charIndex <= 0) goto L63;
         */
        /* JADX WARN: Code restructure failed: missing block: B:52:0x0079, code lost:
        
            switch(dirTypeBackward()) {
                case 14: goto L66;
                case 15: goto L66;
                case 16: goto L65;
                case 17: goto L65;
                case 18: goto L64;
                default: goto L70;
            };
         */
        /* JADX WARN: Code restructure failed: missing block: B:54:0x007d, code lost:
        
            r5 = r5 + 1;
         */
        /* JADX WARN: Code restructure failed: missing block: B:58:0x0080, code lost:
        
            if (r3 != r5) goto L43;
         */
        /* JADX WARN: Code restructure failed: missing block: B:59:0x0086, code lost:
        
            r5 = r5 - 1;
         */
        /* JADX WARN: Code restructure failed: missing block: B:62:0x0082, code lost:
        
            return 1;
         */
        /* JADX WARN: Code restructure failed: missing block: B:64:0x0083, code lost:
        
            if (r3 != r5) goto L43;
         */
        /* JADX WARN: Code restructure failed: missing block: B:66:0x0085, code lost:
        
            return -1;
         */
        /* JADX WARN: Code restructure failed: missing block: B:69:0x0089, code lost:
        
            return 0;
         */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        final int getEntryDir() {
            /*
                r9 = this;
                r0 = 0
                r9.charIndex = r0
                r1 = -1
                r2 = 1
                r3 = 0
                r4 = 0
                r5 = 0
            L8:
                int r6 = r9.charIndex
                int r7 = r9.length
                if (r6 >= r7) goto L6b
                if (r3 != 0) goto L6b
                java.lang.CharSequence r7 = r9.text
                char r6 = r7.charAt(r6)
                r9.lastChar = r6
                boolean r6 = java.lang.Character.isHighSurrogate(r6)
                if (r6 == 0) goto L34
                java.lang.CharSequence r6 = r9.text
                int r7 = r9.charIndex
                int r6 = java.lang.Character.codePointAt(r6, r7)
                int r7 = r9.charIndex
                int r8 = java.lang.Character.charCount(r6)
                int r8 = r8 + r7
                r9.charIndex = r8
                byte r6 = java.lang.Character.getDirectionality(r6)
                goto L48
            L34:
                int r6 = r9.charIndex
                int r6 = r6 + r2
                r9.charIndex = r6
                char r6 = r9.lastChar
                r7 = 1792(0x700, float:2.511E-42)
                if (r6 >= r7) goto L44
                byte[] r7 = android.support.v4.text.BidiFormatter.DirectionalityEstimator.DIR_TYPE_CACHE
                r6 = r7[r6]
                goto L48
            L44:
                byte r6 = java.lang.Character.getDirectionality(r6)
            L48:
                if (r6 == 0) goto L66
                if (r6 == r2) goto L63
                r7 = 2
                if (r6 == r7) goto L63
                r7 = 9
                if (r6 == r7) goto L8
                switch(r6) {
                    case 14: goto L5f;
                    case 15: goto L5f;
                    case 16: goto L5b;
                    case 17: goto L5b;
                    case 18: goto L57;
                    default: goto L56;
                }
            L56:
                goto L69
            L57:
                int r5 = r5 + (-1)
                r4 = 0
                goto L8
            L5b:
                int r5 = r5 + 1
                r4 = 1
                goto L8
            L5f:
                int r5 = r5 + 1
                r4 = -1
                goto L8
            L63:
                if (r5 != 0) goto L69
                return r2
            L66:
                if (r5 != 0) goto L69
                return r1
            L69:
                r3 = r5
                goto L8
            L6b:
                if (r3 != 0) goto L6e
                return r0
            L6e:
                if (r4 == 0) goto L71
                return r4
            L71:
                int r4 = r9.charIndex
                if (r4 <= 0) goto L89
                byte r4 = r9.dirTypeBackward()
                switch(r4) {
                    case 14: goto L83;
                    case 15: goto L83;
                    case 16: goto L80;
                    case 17: goto L80;
                    case 18: goto L7d;
                    default: goto L7c;
                }
            L7c:
                goto L71
            L7d:
                int r5 = r5 + 1
                goto L71
            L80:
                if (r3 != r5) goto L86
                return r2
            L83:
                if (r3 != r5) goto L86
                return r1
            L86:
                int r5 = r5 + (-1)
                goto L71
            L89:
                return r0
            */
            throw new UnsupportedOperationException("Method not decompiled: android.support.v4.text.BidiFormatter.DirectionalityEstimator.getEntryDir():int");
        }

        final int getExitDir() {
            this.charIndex = this.length;
            int i = 0;
            int i2 = 0;
            while (this.charIndex > 0) {
                byte dirTypeBackward = dirTypeBackward();
                if (dirTypeBackward != 0) {
                    if (dirTypeBackward == 1 || dirTypeBackward == 2) {
                        if (i == 0) {
                            return 1;
                        }
                        if (i2 == 0) {
                            i2 = i;
                        }
                    } else if (dirTypeBackward != 9) {
                        switch (dirTypeBackward) {
                            case 14:
                            case 15:
                                if (i2 == i) {
                                    return -1;
                                }
                                i--;
                                break;
                            case 16:
                            case 17:
                                if (i2 == i) {
                                    return 1;
                                }
                                i--;
                                break;
                            case 18:
                                i++;
                                break;
                            default:
                                if (i2 != 0) {
                                    break;
                                } else {
                                    i2 = i;
                                    break;
                                }
                        }
                    } else {
                        continue;
                    }
                } else {
                    if (i == 0) {
                        return -1;
                    }
                    if (i2 == 0) {
                        i2 = i;
                    }
                }
            }
            return 0;
        }
    }

    static {
        TextDirectionHeuristicCompat textDirectionHeuristicCompat = TextDirectionHeuristicsCompat.FIRSTSTRONG_LTR;
        DEFAULT_TEXT_DIRECTION_HEURISTIC = textDirectionHeuristicCompat;
        LRM_STRING = Character.toString((char) 8206);
        RLM_STRING = Character.toString((char) 8207);
        DEFAULT_LTR_INSTANCE = new BidiFormatter(false, 2, textDirectionHeuristicCompat);
        DEFAULT_RTL_INSTANCE = new BidiFormatter(true, 2, textDirectionHeuristicCompat);
    }

    BidiFormatter(boolean z, int i, TextDirectionHeuristicCompat textDirectionHeuristicCompat) {
        this.mIsRtlContext = z;
        this.mFlags = i;
        this.mDefaultTextDirectionHeuristicCompat = textDirectionHeuristicCompat;
    }

    public static BidiFormatter getInstance() {
        return new Builder().build();
    }

    public boolean getStereoReset() {
        return (this.mFlags & 2) != 0;
    }

    public boolean isRtl(String str) {
        return isRtl((CharSequence) str);
    }

    public boolean isRtlContext() {
        return this.mIsRtlContext;
    }

    public String unicodeWrap(String str, TextDirectionHeuristicCompat textDirectionHeuristicCompat, boolean z) {
        if (str == null) {
            return null;
        }
        return unicodeWrap((CharSequence) str, textDirectionHeuristicCompat, z).toString();
    }

    public static BidiFormatter getInstance(boolean z) {
        return new Builder(z).build();
    }

    public boolean isRtl(CharSequence charSequence) {
        return this.mDefaultTextDirectionHeuristicCompat.isRtl(charSequence, 0, charSequence.length());
    }

    public CharSequence unicodeWrap(CharSequence charSequence, TextDirectionHeuristicCompat textDirectionHeuristicCompat, boolean z) {
        if (charSequence == null) {
            return null;
        }
        boolean isRtl = textDirectionHeuristicCompat.isRtl(charSequence, 0, charSequence.length());
        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
        String str = "";
        if (getStereoReset() && z) {
            boolean isRtl2 = (isRtl ? TextDirectionHeuristicsCompat.RTL : TextDirectionHeuristicsCompat.LTR).isRtl(charSequence, 0, charSequence.length());
            spannableStringBuilder.append((CharSequence) ((this.mIsRtlContext || !(isRtl2 || new DirectionalityEstimator(charSequence).getEntryDir() == 1)) ? (!this.mIsRtlContext || (isRtl2 && new DirectionalityEstimator(charSequence).getEntryDir() != -1)) ? "" : RLM_STRING : LRM_STRING));
        }
        if (isRtl != this.mIsRtlContext) {
            spannableStringBuilder.append(isRtl ? (char) 8235 : (char) 8234);
            spannableStringBuilder.append(charSequence);
            spannableStringBuilder.append((char) 8236);
        } else {
            spannableStringBuilder.append(charSequence);
        }
        if (z) {
            boolean isRtl3 = (isRtl ? TextDirectionHeuristicsCompat.RTL : TextDirectionHeuristicsCompat.LTR).isRtl(charSequence, 0, charSequence.length());
            if (!this.mIsRtlContext && (isRtl3 || new DirectionalityEstimator(charSequence).getExitDir() == 1)) {
                str = LRM_STRING;
            } else if (this.mIsRtlContext && (!isRtl3 || new DirectionalityEstimator(charSequence).getExitDir() == -1)) {
                str = RLM_STRING;
            }
            spannableStringBuilder.append((CharSequence) str);
        }
        return spannableStringBuilder;
    }

    public static BidiFormatter getInstance(Locale locale) {
        return new Builder(locale).build();
    }

    public final class Builder {
        private int mFlags;
        private boolean mIsRtlContext;
        private TextDirectionHeuristicCompat mTextDirectionHeuristicCompat;

        public Builder() {
            Locale locale = Locale.getDefault();
            TextDirectionHeuristicCompat textDirectionHeuristicCompat = BidiFormatter.DEFAULT_TEXT_DIRECTION_HEURISTIC;
            this.mIsRtlContext = TextUtilsCompat.getLayoutDirectionFromLocale(locale) == 1;
            this.mTextDirectionHeuristicCompat = BidiFormatter.DEFAULT_TEXT_DIRECTION_HEURISTIC;
            this.mFlags = 2;
        }

        public BidiFormatter build() {
            return (this.mFlags == 2 && this.mTextDirectionHeuristicCompat == BidiFormatter.DEFAULT_TEXT_DIRECTION_HEURISTIC) ? this.mIsRtlContext ? BidiFormatter.DEFAULT_RTL_INSTANCE : BidiFormatter.DEFAULT_LTR_INSTANCE : new BidiFormatter(this.mIsRtlContext, this.mFlags, this.mTextDirectionHeuristicCompat);
        }

        public Builder setTextDirectionHeuristic(TextDirectionHeuristicCompat textDirectionHeuristicCompat) {
            this.mTextDirectionHeuristicCompat = textDirectionHeuristicCompat;
            return this;
        }

        public Builder stereoReset(boolean z) {
            if (z) {
                this.mFlags |= 2;
            } else {
                this.mFlags &= -3;
            }
            return this;
        }

        public Builder(boolean z) {
            this.mIsRtlContext = z;
            this.mTextDirectionHeuristicCompat = BidiFormatter.DEFAULT_TEXT_DIRECTION_HEURISTIC;
            this.mFlags = 2;
        }

        public Builder(Locale locale) {
            TextDirectionHeuristicCompat textDirectionHeuristicCompat = BidiFormatter.DEFAULT_TEXT_DIRECTION_HEURISTIC;
            this.mIsRtlContext = TextUtilsCompat.getLayoutDirectionFromLocale(locale) == 1;
            this.mTextDirectionHeuristicCompat = BidiFormatter.DEFAULT_TEXT_DIRECTION_HEURISTIC;
            this.mFlags = 2;
        }
    }

    public String unicodeWrap(String str, TextDirectionHeuristicCompat textDirectionHeuristicCompat) {
        return unicodeWrap(str, textDirectionHeuristicCompat, true);
    }

    public CharSequence unicodeWrap(CharSequence charSequence, TextDirectionHeuristicCompat textDirectionHeuristicCompat) {
        return unicodeWrap(charSequence, textDirectionHeuristicCompat, true);
    }

    public String unicodeWrap(String str, boolean z) {
        return unicodeWrap(str, this.mDefaultTextDirectionHeuristicCompat, z);
    }

    public CharSequence unicodeWrap(CharSequence charSequence, boolean z) {
        return unicodeWrap(charSequence, this.mDefaultTextDirectionHeuristicCompat, z);
    }

    public String unicodeWrap(String str) {
        return unicodeWrap(str, this.mDefaultTextDirectionHeuristicCompat, true);
    }

    public CharSequence unicodeWrap(CharSequence charSequence) {
        return unicodeWrap(charSequence, this.mDefaultTextDirectionHeuristicCompat, true);
    }
}
