package android.support.v4.graphics;

/* loaded from: classes.dex */
class TypefaceCompatApi21Impl extends TypefaceCompatBaseImpl {
    TypefaceCompatApi21Impl() {
    }

    /* JADX WARN: Removed duplicated region for block: B:18:0x0056 A[Catch: IOException -> 0x0087, TRY_ENTER, TRY_LEAVE, TryCatch #2 {IOException -> 0x0087, blocks: (B:7:0x000e, B:18:0x0056, B:24:0x006a, B:46:0x0086, B:51:0x0083, B:48:0x007e, B:9:0x0018, B:11:0x003d, B:13:0x0049, B:16:0x0050, B:20:0x005a, B:23:0x0067, B:34:0x0079, B:37:0x0076, B:42:0x007a), top: B:6:0x000e, inners: #1, #3, #6 }] */
    @Override // android.support.v4.graphics.TypefaceCompatBaseImpl
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public android.graphics.Typeface createFromFontInfo(android.content.Context r4, android.os.CancellationSignal r5, android.support.v4.provider.FontsContractCompat.FontInfo[] r6, int r7) {
        /*
            r3 = this;
            int r0 = r6.length
            r1 = 0
            r2 = 1
            if (r0 >= r2) goto L6
            return r1
        L6:
            android.support.v4.provider.FontsContractCompat$FontInfo r6 = android.support.v4.graphics.TypefaceCompatBaseImpl.findBestInfo(r7, r6)
            android.content.ContentResolver r7 = r4.getContentResolver()
            android.net.Uri r6 = r6.getUri()     // Catch: java.io.IOException -> L87
            java.lang.String r0 = "r"
            android.os.ParcelFileDescriptor r5 = r7.openFileDescriptor(r6, r0, r5)     // Catch: java.io.IOException -> L87
            java.lang.StringBuilder r6 = new java.lang.StringBuilder     // Catch: java.lang.Throwable -> L43 android.system.ErrnoException -> L45
            r6.<init>()     // Catch: java.lang.Throwable -> L43 android.system.ErrnoException -> L45
            java.lang.String r7 = "/proc/self/fd/"
            r6.append(r7)     // Catch: java.lang.Throwable -> L43 android.system.ErrnoException -> L45
            int r7 = r5.getFd()     // Catch: java.lang.Throwable -> L43 android.system.ErrnoException -> L45
            r6.append(r7)     // Catch: java.lang.Throwable -> L43 android.system.ErrnoException -> L45
            java.lang.String r6 = r6.toString()     // Catch: java.lang.Throwable -> L43 android.system.ErrnoException -> L45
            java.lang.String r6 = android.system.Os.readlink(r6)     // Catch: java.lang.Throwable -> L43 android.system.ErrnoException -> L45
            android.system.StructStat r7 = android.system.Os.stat(r6)     // Catch: java.lang.Throwable -> L43 android.system.ErrnoException -> L45
            int r7 = r7.st_mode     // Catch: java.lang.Throwable -> L43 android.system.ErrnoException -> L45
            boolean r7 = android.system.OsConstants.S_ISREG(r7)     // Catch: java.lang.Throwable -> L43 android.system.ErrnoException -> L45
            if (r7 == 0) goto L46
            java.io.File r7 = new java.io.File     // Catch: java.lang.Throwable -> L43 android.system.ErrnoException -> L45
            r7.<init>(r6)     // Catch: java.lang.Throwable -> L43 android.system.ErrnoException -> L45
            goto L47
        L43:
            r4 = move-exception
            goto L7a
        L45:
        L46:
            r7 = r1
        L47:
            if (r7 == 0) goto L5a
            boolean r6 = r7.canRead()     // Catch: java.lang.Throwable -> L43
            if (r6 != 0) goto L50
            goto L5a
        L50:
            android.graphics.Typeface r4 = android.graphics.Typeface.createFromFile(r7)     // Catch: java.lang.Throwable -> L43
            if (r5 == 0) goto L59
            r5.close()     // Catch: java.io.IOException -> L87
        L59:
            return r4
        L5a:
            java.io.FileInputStream r6 = new java.io.FileInputStream     // Catch: java.lang.Throwable -> L43
            java.io.FileDescriptor r7 = r5.getFileDescriptor()     // Catch: java.lang.Throwable -> L43
            r6.<init>(r7)     // Catch: java.lang.Throwable -> L43
            android.graphics.Typeface r4 = android.support.v4.graphics.TypefaceCompatBaseImpl.createFromInputStream(r4, r6)     // Catch: java.lang.Throwable -> L6e
            r6.close()     // Catch: java.lang.Throwable -> L43
            r5.close()     // Catch: java.io.IOException -> L87
            return r4
        L6e:
            r4 = move-exception
            throw r4     // Catch: java.lang.Throwable -> L70
        L70:
            r7 = move-exception
            r6.close()     // Catch: java.lang.Throwable -> L75
            goto L79
        L75:
            r6 = move-exception
            r4.addSuppressed(r6)     // Catch: java.lang.Throwable -> L43
        L79:
            throw r7     // Catch: java.lang.Throwable -> L43
        L7a:
            throw r4     // Catch: java.lang.Throwable -> L7b
        L7b:
            r6 = move-exception
            if (r5 == 0) goto L86
            r5.close()     // Catch: java.lang.Throwable -> L82
            goto L86
        L82:
            r5 = move-exception
            r4.addSuppressed(r5)     // Catch: java.io.IOException -> L87
        L86:
            throw r6     // Catch: java.io.IOException -> L87
        L87:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.graphics.TypefaceCompatApi21Impl.createFromFontInfo(android.content.Context, android.os.CancellationSignal, android.support.v4.provider.FontsContractCompat$FontInfo[], int):android.graphics.Typeface");
    }
}
