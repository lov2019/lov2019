package android.support.v4.util;

import android.support.annotation.NonNull;

/* loaded from: classes.dex */
public final class Pools {

    public interface Pool {
    }

    public class SimplePool implements Pool {
        private final Object[] mPool;
        private int mPoolSize;

        public SimplePool(int i) {
            if (i <= 0) {
                throw new IllegalArgumentException("The max pool size must be > 0");
            }
            this.mPool = new Object[i];
        }

        public Object acquire() {
            int i = this.mPoolSize;
            if (i <= 0) {
                return null;
            }
            int i2 = i - 1;
            Object[] objArr = this.mPool;
            Object obj = objArr[i2];
            objArr[i2] = null;
            this.mPoolSize = i - 1;
            return obj;
        }

        public boolean release(@NonNull Object obj) {
            int i;
            boolean z;
            int i2 = 0;
            while (true) {
                i = this.mPoolSize;
                if (i2 >= i) {
                    z = false;
                    break;
                }
                if (this.mPool[i2] == obj) {
                    z = true;
                    break;
                }
                i2++;
            }
            if (z) {
                throw new IllegalStateException("Already in the pool!");
            }
            Object[] objArr = this.mPool;
            if (i >= objArr.length) {
                return false;
            }
            objArr[i] = obj;
            this.mPoolSize = i + 1;
            return true;
        }
    }

    public class SynchronizedPool extends SimplePool {
        private final Object mLock;

        public SynchronizedPool(int i) {
            super(i);
            this.mLock = new Object();
        }

        @Override // android.support.v4.util.Pools.SimplePool
        public final Object acquire() {
            Object acquire;
            synchronized (this.mLock) {
                acquire = super.acquire();
            }
            return acquire;
        }

        @Override // android.support.v4.util.Pools.SimplePool
        public final boolean release(Object obj) {
            boolean release;
            synchronized (this.mLock) {
                release = super.release(obj);
            }
            return release;
        }
    }

    private Pools() {
    }
}
