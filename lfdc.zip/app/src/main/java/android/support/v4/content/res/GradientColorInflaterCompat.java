package android.support.v4.content.res;

import java.util.ArrayList;

/* loaded from: classes.dex */
abstract class GradientColorInflaterCompat {
    /* JADX WARN: Code restructure failed: missing block: B:60:0x0107, code lost:
    
        throw new org.xmlpull.v1.XmlPullParserException(r29.getPositionDescription() + ": <item> tag requires a 'color' attribute and a 'offset' attribute!");
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    static android.graphics.Shader createFromXmlInner(android.content.res.Resources r28, android.content.res.XmlResourceParser r29, android.util.AttributeSet r30, android.content.res.Resources.Theme r31) {
        /*
            Method dump skipped, instructions count: 432
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.content.res.GradientColorInflaterCompat.createFromXmlInner(android.content.res.Resources, android.content.res.XmlResourceParser, android.util.AttributeSet, android.content.res.Resources$Theme):android.graphics.Shader");
    }

    final class ColorStops {
        final int[] mColors;
        final float[] mOffsets;

        ColorStops(ArrayList arrayList, ArrayList arrayList2) {
            int size = arrayList.size();
            this.mColors = new int[size];
            this.mOffsets = new float[size];
            for (int i = 0; i < size; i++) {
                this.mColors[i] = ((Integer) arrayList.get(i)).intValue();
                this.mOffsets[i] = ((Float) arrayList2.get(i)).floatValue();
            }
        }

        ColorStops(int i, int i2) {
            this.mColors = new int[]{i, i2};
            this.mOffsets = new float[]{0.0f, 1.0f};
        }

        ColorStops(int i, int i2, int i3) {
            this.mColors = new int[]{i, i2, i3};
            this.mOffsets = new float[]{0.0f, 0.5f, 1.0f};
        }
    }
}
