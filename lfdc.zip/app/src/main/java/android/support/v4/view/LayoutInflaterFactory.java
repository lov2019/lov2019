package android.support.v4.view;

import android.view.View;

@Deprecated
/* loaded from: classes.dex */
public interface LayoutInflaterFactory {
    View onCreateView();
}
