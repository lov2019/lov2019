package android.support.v4.internal.view;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.support.annotation.RestrictTo;
import android.support.v4.view.ActionProvider;
import android.view.MenuItem;

@RestrictTo
/* loaded from: classes.dex */
public interface SupportMenuItem extends MenuItem {
    @Override // android.view.MenuItem
    int getAlphabeticModifiers();

    @Override // android.view.MenuItem
    CharSequence getContentDescription();

    @Override // android.view.MenuItem
    ColorStateList getIconTintList();

    @Override // android.view.MenuItem
    PorterDuff.Mode getIconTintMode();

    @Override // android.view.MenuItem
    int getNumericModifiers();

    ActionProvider getSupportActionProvider();

    @Override // android.view.MenuItem
    CharSequence getTooltipText();

    MenuItem setAlphabeticShortcut();

    SupportMenuItem setContentDescription();

    MenuItem setIconTintList();

    MenuItem setIconTintMode();

    MenuItem setNumericShortcut();

    MenuItem setShortcut();

    SupportMenuItem setSupportActionProvider();

    SupportMenuItem setTooltipText();
}
