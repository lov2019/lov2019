package android.support.v4.view;

/* loaded from: classes.dex */
public final class InputDeviceCompat {
    private InputDeviceCompat() {
    }
}
