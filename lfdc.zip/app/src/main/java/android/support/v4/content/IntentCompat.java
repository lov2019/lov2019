package android.support.v4.content;

import android.content.Intent;
import android.support.annotation.NonNull;

/* loaded from: classes.dex */
public final class IntentCompat {
    private IntentCompat() {
    }

    @NonNull
    public static Intent makeMainSelectorActivity(@NonNull String str, @NonNull String str2) {
        return Intent.makeMainSelectorActivity(str, str2);
    }
}
