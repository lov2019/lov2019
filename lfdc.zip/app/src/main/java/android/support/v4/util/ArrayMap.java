package android.support.v4.util;

import android.support.annotation.NonNull;
import android.support.v4.util.MapCollections;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/* loaded from: classes.dex */
public class ArrayMap extends SimpleArrayMap implements Map {
    AnonymousClass1 mCollections;

    /* renamed from: android.support.v4.util.ArrayMap$1, reason: invalid class name */
    final class AnonymousClass1 extends MapCollections {
        public final /* synthetic */ int $r8$classId;
        final /* synthetic */ Object this$0;

        public /* synthetic */ AnonymousClass1(int i, Object obj) {
            this.$r8$classId = i;
            this.this$0 = obj;
        }

        @Override // android.support.v4.util.MapCollections
        protected final void colClear() {
            switch (this.$r8$classId) {
                case 0:
                    ((ArrayMap) this.this$0).clear();
                    break;
                default:
                    ((ArraySet) this.this$0).clear();
                    break;
            }
        }

        @Override // android.support.v4.util.MapCollections
        protected final Object colGetEntry(int i, int i2) {
            switch (this.$r8$classId) {
                case 0:
                    return ((ArrayMap) this.this$0).mArray[(i << 1) + i2];
                default:
                    return ((ArraySet) this.this$0).mArray[i];
            }
        }

        @Override // android.support.v4.util.MapCollections
        protected final ArrayMap colGetMap() {
            switch (this.$r8$classId) {
                case 0:
                    return (ArrayMap) this.this$0;
                default:
                    throw new UnsupportedOperationException("not a map");
            }
        }

        @Override // android.support.v4.util.MapCollections
        protected final int colGetSize() {
            switch (this.$r8$classId) {
                case 0:
                    return ((ArrayMap) this.this$0).mSize;
                default:
                    return ((ArraySet) this.this$0).mSize;
            }
        }

        @Override // android.support.v4.util.MapCollections
        protected final int colIndexOfKey(Object obj) {
            switch (this.$r8$classId) {
                case 0:
                    return ((ArrayMap) this.this$0).indexOfKey(obj);
                default:
                    return ((ArraySet) this.this$0).indexOf(obj);
            }
        }

        @Override // android.support.v4.util.MapCollections
        protected final int colIndexOfValue(Object obj) {
            switch (this.$r8$classId) {
                case 0:
                    return ((ArrayMap) this.this$0).indexOfValue(obj);
                default:
                    return ((ArraySet) this.this$0).indexOf(obj);
            }
        }

        @Override // android.support.v4.util.MapCollections
        protected final void colRemoveAt(int i) {
            switch (this.$r8$classId) {
                case 0:
                    ((ArrayMap) this.this$0).removeAt(i);
                    break;
                default:
                    ((ArraySet) this.this$0).removeAt(i);
                    break;
            }
        }
    }

    public ArrayMap() {
    }

    public boolean containsAll(@NonNull Collection collection) {
        Iterator it = collection.iterator();
        while (it.hasNext()) {
            if (!containsKey(it.next())) {
                return false;
            }
        }
        return true;
    }

    @Override // java.util.Map
    public Set entrySet() {
        if (this.mCollections == null) {
            this.mCollections = new AnonymousClass1(0, this);
        }
        AnonymousClass1 anonymousClass1 = this.mCollections;
        if (anonymousClass1.mEntrySet == null) {
            anonymousClass1.mEntrySet = new MapCollections.KeySet(anonymousClass1, 1);
        }
        return anonymousClass1.mEntrySet;
    }

    @Override // java.util.Map
    public Set keySet() {
        int i = 0;
        if (this.mCollections == null) {
            this.mCollections = new AnonymousClass1(i, this);
        }
        AnonymousClass1 anonymousClass1 = this.mCollections;
        if (anonymousClass1.mKeySet == null) {
            anonymousClass1.mKeySet = new MapCollections.KeySet(anonymousClass1, i);
        }
        return anonymousClass1.mKeySet;
    }

    @Override // java.util.Map
    public void putAll(Map map) {
        ensureCapacity(map.size() + this.mSize);
        for (Map.Entry entry : map.entrySet()) {
            put(entry.getKey(), entry.getValue());
        }
    }

    public boolean removeAll(@NonNull Collection collection) {
        return MapCollections.removeAllHelper(this, collection);
    }

    public boolean retainAll(@NonNull Collection collection) {
        return MapCollections.retainAllHelper(this, collection);
    }

    @Override // java.util.Map
    public Collection values() {
        if (this.mCollections == null) {
            this.mCollections = new AnonymousClass1(0, this);
        }
        AnonymousClass1 anonymousClass1 = this.mCollections;
        if (anonymousClass1.mValues == null) {
            anonymousClass1.mValues = new MapCollections.ValuesCollection();
        }
        return anonymousClass1.mValues;
    }

    public ArrayMap(int i) {
        super(i);
    }

    public ArrayMap(SimpleArrayMap simpleArrayMap) {
        super(simpleArrayMap);
    }
}
