package android.support.v4.view;

/* loaded from: classes.dex */
public interface OnApplyWindowInsetsListener {
    WindowInsetsCompat onApplyWindowInsets();
}
