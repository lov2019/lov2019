package android.support.v4.graphics;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.CancellationSignal;
import android.support.v4.content.res.FontResourcesParserCompat;
import android.support.v4.provider.FontsContractCompat;
import java.io.File;
import java.io.InputStream;

/* loaded from: classes.dex */
abstract class TypefaceCompatBaseImpl {

    /* renamed from: android.support.v4.graphics.TypefaceCompatBaseImpl$1, reason: invalid class name */
    final class AnonymousClass1 {
        public final /* synthetic */ int $r8$classId;

        public /* synthetic */ AnonymousClass1(int i) {
            this.$r8$classId = i;
        }
    }

    TypefaceCompatBaseImpl() {
    }

    protected static Typeface createFromInputStream(Context context, InputStream inputStream) {
        File tempFile = TypefaceCompatUtil.getTempFile(context);
        if (tempFile == null) {
            return null;
        }
        try {
            if (TypefaceCompatUtil.copyToFile(tempFile, inputStream)) {
                return Typeface.createFromFile(tempFile.getPath());
            }
            return null;
        } catch (RuntimeException unused) {
            return null;
        } finally {
            tempFile.delete();
        }
    }

    private static Object findBestFont(Object[] objArr, int i, AnonymousClass1 anonymousClass1) {
        int weight;
        boolean isItalic;
        int i2 = (i & 1) == 0 ? 400 : 700;
        boolean z = (i & 2) != 0;
        Object obj = null;
        int i3 = Integer.MAX_VALUE;
        for (Object obj2 : objArr) {
            switch (anonymousClass1.$r8$classId) {
                case 0:
                    weight = ((FontsContractCompat.FontInfo) obj2).getWeight();
                    break;
                default:
                    weight = ((FontResourcesParserCompat.FontFileResourceEntry) obj2).getWeight();
                    break;
            }
            int abs = Math.abs(weight - i2) * 2;
            switch (anonymousClass1.$r8$classId) {
                case 0:
                    isItalic = ((FontsContractCompat.FontInfo) obj2).isItalic();
                    break;
                default:
                    isItalic = ((FontResourcesParserCompat.FontFileResourceEntry) obj2).isItalic();
                    break;
            }
            int i4 = abs + (isItalic == z ? 0 : 1);
            if (obj == null || i3 > i4) {
                obj = obj2;
                i3 = i4;
            }
        }
        return obj;
    }

    protected static FontsContractCompat.FontInfo findBestInfo(int i, FontsContractCompat.FontInfo[] fontInfoArr) {
        return (FontsContractCompat.FontInfo) findBestFont(fontInfoArr, i, new AnonymousClass1(0));
    }

    public Typeface createFromFontFamilyFilesResourceEntry(Context context, FontResourcesParserCompat.FontFamilyFilesResourceEntry fontFamilyFilesResourceEntry, Resources resources, int i) {
        FontResourcesParserCompat.FontFileResourceEntry fontFileResourceEntry = (FontResourcesParserCompat.FontFileResourceEntry) findBestFont(fontFamilyFilesResourceEntry.getEntries(), i, new AnonymousClass1(1));
        if (fontFileResourceEntry == null) {
            return null;
        }
        return TypefaceCompat.createFromResourcesFontFile(context, resources, fontFileResourceEntry.getResourceId(), fontFileResourceEntry.getFileName(), i);
    }

    public abstract Typeface createFromFontInfo(Context context, CancellationSignal cancellationSignal, FontsContractCompat.FontInfo[] fontInfoArr, int i);

    public Typeface createFromResourcesFontFile(Context context, Resources resources, int i, String str, int i2) {
        File tempFile = TypefaceCompatUtil.getTempFile(context);
        if (tempFile == null) {
            return null;
        }
        try {
            if (TypefaceCompatUtil.copyToFile(tempFile, resources, i)) {
                return Typeface.createFromFile(tempFile.getPath());
            }
            return null;
        } catch (RuntimeException unused) {
            return null;
        } finally {
            tempFile.delete();
        }
    }
}
