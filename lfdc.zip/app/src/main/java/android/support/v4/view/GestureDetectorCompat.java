package android.support.v4.view;

import android.content.Context;
import android.os.Handler;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.ViewConfiguration;

/* loaded from: classes.dex */
public final class GestureDetectorCompat {
    private final GestureDetectorCompatImplJellybeanMr2 mImpl;

    interface GestureDetectorCompatImpl {
    }

    class GestureDetectorCompatImplBase implements GestureDetectorCompatImpl {
        private boolean mAlwaysInTapRegion;
        MotionEvent mCurrentDownEvent;
        GestureDetector.OnDoubleTapListener mDoubleTapListener;
        private float mDownFocusX;
        private float mDownFocusY;
        private boolean mInLongPress;
        private boolean mIsDoubleTapping;
        private boolean mIsLongpressEnabled;
        private float mLastFocusX;
        private float mLastFocusY;
        private MotionEvent mPreviousUpEvent;
        private VelocityTracker mVelocityTracker;

        static {
            ViewConfiguration.getLongPressTimeout();
            ViewConfiguration.getTapTimeout();
            ViewConfiguration.getDoubleTapTimeout();
        }

        public boolean isLongpressEnabled() {
            return this.mIsLongpressEnabled;
        }

        public boolean onTouchEvent(MotionEvent motionEvent) {
            int action = motionEvent.getAction();
            if (this.mVelocityTracker == null) {
                this.mVelocityTracker = VelocityTracker.obtain();
            }
            this.mVelocityTracker.addMovement(motionEvent);
            int i = action & 255;
            boolean z = i == 6;
            int actionIndex = z ? motionEvent.getActionIndex() : -1;
            int pointerCount = motionEvent.getPointerCount();
            float f = 0.0f;
            float f2 = 0.0f;
            for (int i2 = 0; i2 < pointerCount; i2++) {
                if (actionIndex != i2) {
                    f += motionEvent.getX(i2);
                    f2 += motionEvent.getY(i2);
                }
            }
            float f3 = z ? pointerCount - 1 : pointerCount;
            float f4 = f / f3;
            float f5 = f2 / f3;
            if (i == 0) {
                if (this.mDoubleTapListener != null) {
                    throw null;
                }
                this.mLastFocusX = f4;
                this.mDownFocusX = f4;
                this.mLastFocusY = f5;
                this.mDownFocusY = f5;
                MotionEvent motionEvent2 = this.mCurrentDownEvent;
                if (motionEvent2 != null) {
                    motionEvent2.recycle();
                }
                MotionEvent obtain = MotionEvent.obtain(motionEvent);
                this.mCurrentDownEvent = obtain;
                this.mAlwaysInTapRegion = true;
                this.mInLongPress = false;
                if (this.mIsLongpressEnabled) {
                    throw null;
                }
                obtain.getDownTime();
                throw null;
            }
            if (i == 1) {
                MotionEvent obtain2 = MotionEvent.obtain(motionEvent);
                if (this.mIsDoubleTapping) {
                    this.mDoubleTapListener.onDoubleTapEvent(motionEvent);
                } else {
                    if (this.mInLongPress) {
                        throw null;
                    }
                    if (this.mAlwaysInTapRegion) {
                        throw null;
                    }
                    VelocityTracker velocityTracker = this.mVelocityTracker;
                    int pointerId = motionEvent.getPointerId(0);
                    float f6 = 0;
                    velocityTracker.computeCurrentVelocity(1000, f6);
                    float yVelocity = velocityTracker.getYVelocity(pointerId);
                    float xVelocity = velocityTracker.getXVelocity(pointerId);
                    if (Math.abs(yVelocity) > f6) {
                        throw null;
                    }
                    if (Math.abs(xVelocity) > f6) {
                        throw null;
                    }
                }
                MotionEvent motionEvent3 = this.mPreviousUpEvent;
                if (motionEvent3 != null) {
                    motionEvent3.recycle();
                }
                this.mPreviousUpEvent = obtain2;
                VelocityTracker velocityTracker2 = this.mVelocityTracker;
                if (velocityTracker2 != null) {
                    velocityTracker2.recycle();
                    this.mVelocityTracker = null;
                }
                this.mIsDoubleTapping = false;
                throw null;
            }
            if (i == 2) {
                if (this.mInLongPress) {
                    return false;
                }
                float f7 = this.mLastFocusX - f4;
                float f8 = this.mLastFocusY - f5;
                if (this.mIsDoubleTapping) {
                    return false | this.mDoubleTapListener.onDoubleTapEvent(motionEvent);
                }
                if (this.mAlwaysInTapRegion) {
                    int i3 = (int) (f4 - this.mDownFocusX);
                    int i4 = (int) (f5 - this.mDownFocusY);
                    if ((i4 * i4) + (i3 * i3) <= 0) {
                        return false;
                    }
                    throw null;
                }
                if (Math.abs(f7) >= 1.0f) {
                    throw null;
                }
                if (Math.abs(f8) < 1.0f) {
                    return false;
                }
                throw null;
            }
            if (i == 3) {
                throw null;
            }
            if (i == 5) {
                this.mLastFocusX = f4;
                this.mDownFocusX = f4;
                this.mLastFocusY = f5;
                this.mDownFocusY = f5;
                throw null;
            }
            if (i != 6) {
                return false;
            }
            this.mLastFocusX = f4;
            this.mDownFocusX = f4;
            this.mLastFocusY = f5;
            this.mDownFocusY = f5;
            this.mVelocityTracker.computeCurrentVelocity(1000, 0);
            int actionIndex2 = motionEvent.getActionIndex();
            int pointerId2 = motionEvent.getPointerId(actionIndex2);
            float xVelocity2 = this.mVelocityTracker.getXVelocity(pointerId2);
            float yVelocity2 = this.mVelocityTracker.getYVelocity(pointerId2);
            for (int i5 = 0; i5 < pointerCount; i5++) {
                if (i5 != actionIndex2) {
                    int pointerId3 = motionEvent.getPointerId(i5);
                    if ((this.mVelocityTracker.getYVelocity(pointerId3) * yVelocity2) + (this.mVelocityTracker.getXVelocity(pointerId3) * xVelocity2) < 0.0f) {
                        this.mVelocityTracker.clear();
                        return false;
                    }
                }
            }
            return false;
        }

        public void setIsLongpressEnabled(boolean z) {
            this.mIsLongpressEnabled = z;
        }

        public void setOnDoubleTapListener(GestureDetector.OnDoubleTapListener onDoubleTapListener) {
            this.mDoubleTapListener = onDoubleTapListener;
        }
    }

    final class GestureDetectorCompatImplJellybeanMr2 implements GestureDetectorCompatImpl {
        private final GestureDetector mDetector;

        GestureDetectorCompatImplJellybeanMr2(Context context, GestureDetector.OnGestureListener onGestureListener, Handler handler) {
            this.mDetector = new GestureDetector(context, onGestureListener, handler);
        }

        public final boolean isLongpressEnabled() {
            return this.mDetector.isLongpressEnabled();
        }

        public final boolean onTouchEvent(MotionEvent motionEvent) {
            return this.mDetector.onTouchEvent(motionEvent);
        }

        public final void setIsLongpressEnabled(boolean z) {
            this.mDetector.setIsLongpressEnabled(z);
        }

        public final void setOnDoubleTapListener(GestureDetector.OnDoubleTapListener onDoubleTapListener) {
            this.mDetector.setOnDoubleTapListener(onDoubleTapListener);
        }
    }

    public GestureDetectorCompat(Context context, GestureDetector.OnGestureListener onGestureListener) {
        this(context, onGestureListener, null);
    }

    public boolean isLongpressEnabled() {
        return this.mImpl.isLongpressEnabled();
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        return this.mImpl.onTouchEvent(motionEvent);
    }

    public void setIsLongpressEnabled(boolean z) {
        this.mImpl.setIsLongpressEnabled(z);
    }

    public void setOnDoubleTapListener(GestureDetector.OnDoubleTapListener onDoubleTapListener) {
        this.mImpl.setOnDoubleTapListener(onDoubleTapListener);
    }

    public GestureDetectorCompat(Context context, GestureDetector.OnGestureListener onGestureListener, Handler handler) {
        this.mImpl = new GestureDetectorCompatImplJellybeanMr2(context, onGestureListener, handler);
    }
}
