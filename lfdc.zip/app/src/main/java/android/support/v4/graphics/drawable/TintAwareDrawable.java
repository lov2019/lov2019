package android.support.v4.graphics.drawable;

import android.support.annotation.RestrictTo;

@RestrictTo
/* loaded from: classes.dex */
public interface TintAwareDrawable {
}
