package android.support.v4.util;

import android.support.v4.util.ArrayMap;
import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;

/* loaded from: classes.dex */
abstract class MapCollections {
    KeySet mEntrySet;
    KeySet mKeySet;
    ValuesCollection mValues;

    final class ArrayIterator implements Iterator {
        boolean mCanRemove = false;
        int mIndex;
        final int mOffset;
        int mSize;

        ArrayIterator(int i) {
            this.mOffset = i;
            this.mSize = MapCollections.this.colGetSize();
        }

        @Override // java.util.Iterator
        public final boolean hasNext() {
            return this.mIndex < this.mSize;
        }

        @Override // java.util.Iterator
        public final Object next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }
            Object colGetEntry = MapCollections.this.colGetEntry(this.mIndex, this.mOffset);
            this.mIndex++;
            this.mCanRemove = true;
            return colGetEntry;
        }

        @Override // java.util.Iterator
        public final void remove() {
            if (!this.mCanRemove) {
                throw new IllegalStateException();
            }
            int i = this.mIndex - 1;
            this.mIndex = i;
            this.mSize--;
            this.mCanRemove = false;
            MapCollections.this.colRemoveAt(i);
        }
    }

    final class MapIterator implements Iterator, Map.Entry {
        int mEnd;
        boolean mEntryValid = false;
        int mIndex = -1;

        MapIterator() {
            this.mEnd = MapCollections.this.colGetSize() - 1;
        }

        @Override // java.util.Map.Entry
        public final boolean equals(Object obj) {
            if (!this.mEntryValid) {
                throw new IllegalStateException("This container does not support retaining Map.Entry objects");
            }
            if (!(obj instanceof Map.Entry)) {
                return false;
            }
            Map.Entry entry = (Map.Entry) obj;
            Object key = entry.getKey();
            Object colGetEntry = MapCollections.this.colGetEntry(this.mIndex, 0);
            if (!(key == colGetEntry || (key != null && key.equals(colGetEntry)))) {
                return false;
            }
            Object value = entry.getValue();
            Object colGetEntry2 = MapCollections.this.colGetEntry(this.mIndex, 1);
            return value == colGetEntry2 || (value != null && value.equals(colGetEntry2));
        }

        @Override // java.util.Map.Entry
        public final Object getKey() {
            if (this.mEntryValid) {
                return MapCollections.this.colGetEntry(this.mIndex, 0);
            }
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }

        @Override // java.util.Map.Entry
        public final Object getValue() {
            if (this.mEntryValid) {
                return MapCollections.this.colGetEntry(this.mIndex, 1);
            }
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }

        @Override // java.util.Iterator
        public final boolean hasNext() {
            return this.mIndex < this.mEnd;
        }

        @Override // java.util.Map.Entry
        public final int hashCode() {
            if (!this.mEntryValid) {
                throw new IllegalStateException("This container does not support retaining Map.Entry objects");
            }
            Object colGetEntry = MapCollections.this.colGetEntry(this.mIndex, 0);
            Object colGetEntry2 = MapCollections.this.colGetEntry(this.mIndex, 1);
            return (colGetEntry == null ? 0 : colGetEntry.hashCode()) ^ (colGetEntry2 != null ? colGetEntry2.hashCode() : 0);
        }

        @Override // java.util.Iterator
        public final Object next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }
            this.mIndex++;
            this.mEntryValid = true;
            return this;
        }

        @Override // java.util.Iterator
        public final void remove() {
            if (!this.mEntryValid) {
                throw new IllegalStateException();
            }
            MapCollections.this.colRemoveAt(this.mIndex);
            this.mIndex--;
            this.mEnd--;
            this.mEntryValid = false;
        }

        @Override // java.util.Map.Entry
        public final Object setValue(Object obj) {
            if (!this.mEntryValid) {
                throw new IllegalStateException("This container does not support retaining Map.Entry objects");
            }
            MapCollections mapCollections = MapCollections.this;
            int i = this.mIndex;
            ArrayMap.AnonymousClass1 anonymousClass1 = (ArrayMap.AnonymousClass1) mapCollections;
            switch (anonymousClass1.$r8$classId) {
                case 0:
                    return ((ArrayMap) anonymousClass1.this$0).setValueAt(i, obj);
                default:
                    throw new UnsupportedOperationException("not a map");
            }
        }

        public final String toString() {
            return getKey() + "=" + getValue();
        }
    }

    MapCollections() {
    }

    public static boolean equalsSetHelper(Set set, Object obj) {
        if (set == obj) {
            return true;
        }
        if (obj instanceof Set) {
            Set set2 = (Set) obj;
            try {
                if (set.size() == set2.size()) {
                    if (set.containsAll(set2)) {
                        return true;
                    }
                }
                return false;
            } catch (ClassCastException | NullPointerException unused) {
            }
        }
        return false;
    }

    public static boolean removeAllHelper(Map map, Collection collection) {
        int size = map.size();
        Iterator it = collection.iterator();
        while (it.hasNext()) {
            map.remove(it.next());
        }
        return size != map.size();
    }

    public static boolean retainAllHelper(Map map, Collection collection) {
        int size = map.size();
        Iterator it = map.keySet().iterator();
        while (it.hasNext()) {
            if (!collection.contains(it.next())) {
                it.remove();
            }
        }
        return size != map.size();
    }

    protected abstract void colClear();

    protected abstract Object colGetEntry(int i, int i2);

    protected abstract ArrayMap colGetMap();

    protected abstract int colGetSize();

    protected abstract int colIndexOfKey(Object obj);

    protected abstract int colIndexOfValue(Object obj);

    protected abstract void colRemoveAt(int i);

    public final Object[] toArrayHelper(Object[] objArr, int i) {
        int colGetSize = colGetSize();
        if (objArr.length < colGetSize) {
            objArr = (Object[]) Array.newInstance(objArr.getClass().getComponentType(), colGetSize);
        }
        for (int i2 = 0; i2 < colGetSize; i2++) {
            objArr[i2] = colGetEntry(i2, i);
        }
        if (objArr.length > colGetSize) {
            objArr[colGetSize] = null;
        }
        return objArr;
    }

    final class ValuesCollection implements Collection {
        ValuesCollection() {
        }

        @Override // java.util.Collection
        public final boolean add(Object obj) {
            throw new UnsupportedOperationException();
        }

        @Override // java.util.Collection
        public final boolean addAll(Collection collection) {
            throw new UnsupportedOperationException();
        }

        @Override // java.util.Collection
        public final void clear() {
            MapCollections.this.colClear();
        }

        @Override // java.util.Collection
        public final boolean contains(Object obj) {
            return MapCollections.this.colIndexOfValue(obj) >= 0;
        }

        @Override // java.util.Collection
        public final boolean containsAll(Collection collection) {
            Iterator it = collection.iterator();
            while (it.hasNext()) {
                if (!contains(it.next())) {
                    return false;
                }
            }
            return true;
        }

        @Override // java.util.Collection
        public final boolean isEmpty() {
            return MapCollections.this.colGetSize() == 0;
        }

        @Override // java.util.Collection, java.lang.Iterable
        public final Iterator iterator() {
            return MapCollections.this.new ArrayIterator(1);
        }

        @Override // java.util.Collection
        public final boolean remove(Object obj) {
            int colIndexOfValue = MapCollections.this.colIndexOfValue(obj);
            if (colIndexOfValue < 0) {
                return false;
            }
            MapCollections.this.colRemoveAt(colIndexOfValue);
            return true;
        }

        @Override // java.util.Collection
        public final boolean removeAll(Collection collection) {
            int colGetSize = MapCollections.this.colGetSize();
            int i = 0;
            boolean z = false;
            while (i < colGetSize) {
                if (collection.contains(MapCollections.this.colGetEntry(i, 1))) {
                    MapCollections.this.colRemoveAt(i);
                    i--;
                    colGetSize--;
                    z = true;
                }
                i++;
            }
            return z;
        }

        @Override // java.util.Collection
        public final boolean retainAll(Collection collection) {
            int colGetSize = MapCollections.this.colGetSize();
            int i = 0;
            boolean z = false;
            while (i < colGetSize) {
                if (!collection.contains(MapCollections.this.colGetEntry(i, 1))) {
                    MapCollections.this.colRemoveAt(i);
                    i--;
                    colGetSize--;
                    z = true;
                }
                i++;
            }
            return z;
        }

        @Override // java.util.Collection
        public final int size() {
            return MapCollections.this.colGetSize();
        }

        @Override // java.util.Collection
        public final Object[] toArray() {
            MapCollections mapCollections = MapCollections.this;
            int colGetSize = mapCollections.colGetSize();
            Object[] objArr = new Object[colGetSize];
            for (int i = 0; i < colGetSize; i++) {
                objArr[i] = mapCollections.colGetEntry(i, 1);
            }
            return objArr;
        }

        @Override // java.util.Collection
        public final Object[] toArray(Object[] objArr) {
            return MapCollections.this.toArrayHelper(objArr, 1);
        }
    }

    final class KeySet implements Set {
        public final /* synthetic */ int $r8$classId;
        final /* synthetic */ MapCollections this$0;

        public /* synthetic */ KeySet(MapCollections mapCollections, int i) {
            this.$r8$classId = i;
            this.this$0 = mapCollections;
        }

        @Override // java.util.Set, java.util.Collection
        public final boolean add(Object obj) {
            switch (this.$r8$classId) {
                case 0:
                    throw new UnsupportedOperationException();
                default:
                    throw new UnsupportedOperationException();
            }
        }

        @Override // java.util.Set, java.util.Collection
        public final boolean addAll(Collection collection) {
            switch (this.$r8$classId) {
                case 0:
                    throw new UnsupportedOperationException();
                default:
                    int colGetSize = this.this$0.colGetSize();
                    Iterator it = collection.iterator();
                    while (it.hasNext()) {
                        Map.Entry entry = (Map.Entry) it.next();
                        MapCollections mapCollections = this.this$0;
                        Object key = entry.getKey();
                        Object value = entry.getValue();
                        ArrayMap.AnonymousClass1 anonymousClass1 = (ArrayMap.AnonymousClass1) mapCollections;
                        switch (anonymousClass1.$r8$classId) {
                            case 0:
                                ((ArrayMap) anonymousClass1.this$0).put(key, value);
                                break;
                            default:
                                ((ArraySet) anonymousClass1.this$0).add(key);
                                break;
                        }
                    }
                    return colGetSize != this.this$0.colGetSize();
            }
        }

        @Override // java.util.Set, java.util.Collection
        public final void clear() {
            switch (this.$r8$classId) {
                case 0:
                    this.this$0.colClear();
                    break;
                default:
                    this.this$0.colClear();
                    break;
            }
        }

        @Override // java.util.Set, java.util.Collection
        public final boolean contains(Object obj) {
            boolean z = true;
            switch (this.$r8$classId) {
                case 0:
                    return this.this$0.colIndexOfKey(obj) >= 0;
                default:
                    if (!(obj instanceof Map.Entry)) {
                        return false;
                    }
                    Map.Entry entry = (Map.Entry) obj;
                    int colIndexOfKey = this.this$0.colIndexOfKey(entry.getKey());
                    if (colIndexOfKey < 0) {
                        return false;
                    }
                    Object colGetEntry = this.this$0.colGetEntry(colIndexOfKey, 1);
                    Object value = entry.getValue();
                    if (colGetEntry != value && (colGetEntry == null || !colGetEntry.equals(value))) {
                        z = false;
                    }
                    return z;
            }
        }

        @Override // java.util.Set, java.util.Collection
        public final boolean containsAll(Collection collection) {
            switch (this.$r8$classId) {
                case 0:
                    ArrayMap colGetMap = this.this$0.colGetMap();
                    Iterator it = collection.iterator();
                    while (it.hasNext()) {
                        if (!colGetMap.containsKey(it.next())) {
                            break;
                        }
                    }
                    break;
                default:
                    Iterator it2 = collection.iterator();
                    while (it2.hasNext()) {
                        if (!contains(it2.next())) {
                            break;
                        }
                    }
                    break;
            }
            return false;
        }

        @Override // java.util.Set, java.util.Collection
        public final boolean equals(Object obj) {
            switch (this.$r8$classId) {
            }
            return MapCollections.equalsSetHelper(this, obj);
        }

        @Override // java.util.Set, java.util.Collection
        public final int hashCode() {
            switch (this.$r8$classId) {
                case 0:
                    int i = 0;
                    for (int colGetSize = this.this$0.colGetSize() - 1; colGetSize >= 0; colGetSize--) {
                        Object colGetEntry = this.this$0.colGetEntry(colGetSize, 0);
                        i += colGetEntry == null ? 0 : colGetEntry.hashCode();
                    }
                    return i;
                default:
                    int i2 = 0;
                    for (int colGetSize2 = this.this$0.colGetSize() - 1; colGetSize2 >= 0; colGetSize2--) {
                        Object colGetEntry2 = this.this$0.colGetEntry(colGetSize2, 0);
                        Object colGetEntry3 = this.this$0.colGetEntry(colGetSize2, 1);
                        i2 += (colGetEntry2 == null ? 0 : colGetEntry2.hashCode()) ^ (colGetEntry3 == null ? 0 : colGetEntry3.hashCode());
                    }
                    return i2;
            }
        }

        @Override // java.util.Set, java.util.Collection
        public final boolean isEmpty() {
            switch (this.$r8$classId) {
                case 0:
                    if (this.this$0.colGetSize() == 0) {
                    }
                    break;
                default:
                    if (this.this$0.colGetSize() == 0) {
                    }
                    break;
            }
            return false;
        }

        @Override // java.util.Set, java.util.Collection, java.lang.Iterable
        public final Iterator iterator() {
            switch (this.$r8$classId) {
                case 0:
                    return this.this$0.new ArrayIterator(0);
                default:
                    return this.this$0.new MapIterator();
            }
        }

        @Override // java.util.Set, java.util.Collection
        public final boolean remove(Object obj) {
            switch (this.$r8$classId) {
                case 0:
                    int colIndexOfKey = this.this$0.colIndexOfKey(obj);
                    if (colIndexOfKey < 0) {
                        return false;
                    }
                    this.this$0.colRemoveAt(colIndexOfKey);
                    return true;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        @Override // java.util.Set, java.util.Collection
        public final boolean removeAll(Collection collection) {
            switch (this.$r8$classId) {
                case 0:
                    return MapCollections.removeAllHelper(this.this$0.colGetMap(), collection);
                default:
                    throw new UnsupportedOperationException();
            }
        }

        @Override // java.util.Set, java.util.Collection
        public final boolean retainAll(Collection collection) {
            switch (this.$r8$classId) {
                case 0:
                    return MapCollections.retainAllHelper(this.this$0.colGetMap(), collection);
                default:
                    throw new UnsupportedOperationException();
            }
        }

        @Override // java.util.Set, java.util.Collection
        public final int size() {
            switch (this.$r8$classId) {
            }
            return this.this$0.colGetSize();
        }

        @Override // java.util.Set, java.util.Collection
        public final Object[] toArray() {
            switch (this.$r8$classId) {
                case 0:
                    MapCollections mapCollections = this.this$0;
                    int colGetSize = mapCollections.colGetSize();
                    Object[] objArr = new Object[colGetSize];
                    for (int i = 0; i < colGetSize; i++) {
                        objArr[i] = mapCollections.colGetEntry(i, 0);
                    }
                    return objArr;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        @Override // java.util.Set, java.util.Collection
        public final Object[] toArray(Object[] objArr) {
            switch (this.$r8$classId) {
                case 0:
                    return this.this$0.toArrayHelper(objArr, 0);
                default:
                    throw new UnsupportedOperationException();
            }
        }
    }
}
