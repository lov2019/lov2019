package android.support.v4.provider;

import android.content.ContentUris;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.database.Cursor;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.CancellationSignal;
import android.os.Handler;
import android.provider.BaseColumns;
import android.support.annotation.IntRange;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.annotation.RestrictTo;
import android.support.v4.content.res.ResourcesCompat;
import android.support.v4.graphics.TypefaceCompat;
import android.support.v4.graphics.TypefaceCompatUtil;
import android.support.v4.provider.SelfDestructiveThread;
import android.support.v4.util.LruCache;
import android.support.v4.util.Preconditions;
import android.support.v4.util.SimpleArrayMap;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Callable;

/* loaded from: classes.dex */
public class FontsContractCompat {
    static final LruCache sTypefaceCache = new LruCache(16);
    private static final SelfDestructiveThread sBackgroundThread = new SelfDestructiveThread("fonts", 10, 10000);
    static final Object sLock = new Object();
    static final SimpleArrayMap sPendingReplies = new SimpleArrayMap();
    private static final Comparator sByteArrayComparator = new Comparator() { // from class: android.support.v4.provider.FontsContractCompat.5
        @Override // java.util.Comparator
        public final int compare(Object obj, Object obj2) {
            byte[] bArr = (byte[]) obj;
            byte[] bArr2 = (byte[]) obj2;
            if (bArr.length != bArr2.length) {
                return bArr.length - bArr2.length;
            }
            for (int i = 0; i < bArr.length; i++) {
                byte b = bArr[i];
                byte b2 = bArr2[i];
                if (b != b2) {
                    return b - b2;
                }
            }
            return 0;
        }
    };

    /* renamed from: android.support.v4.provider.FontsContractCompat$4, reason: invalid class name */
    final class AnonymousClass4 implements Runnable {
        public final /* synthetic */ int $r8$classId = 0;
        final /* synthetic */ Object val$callback;
        final /* synthetic */ Handler val$callerThreadHandler;
        final /* synthetic */ Object val$context;
        final /* synthetic */ Object val$request;

        public AnonymousClass4(SelfDestructiveThread selfDestructiveThread, Callable callable, Handler handler, SelfDestructiveThread.ReplyCallback replyCallback) {
            this.val$callback = selfDestructiveThread;
            this.val$context = callable;
            this.val$callerThreadHandler = handler;
            this.val$request = replyCallback;
        }

        @Override // java.lang.Runnable
        public final void run() {
            final int i = 1;
            final Object obj = null;
            switch (this.$r8$classId) {
                case 0:
                    final int i2 = 0;
                    try {
                        FontFamilyResult fetchFonts = FontsContractCompat.fetchFonts((Context) this.val$context, null, (FontRequest) this.val$request);
                        if (fetchFonts.getStatusCode() != 0) {
                            int statusCode = fetchFonts.getStatusCode();
                            if (statusCode != 1) {
                                final int i3 = 2;
                                if (statusCode != 2) {
                                    final int i4 = 3;
                                    this.val$callerThreadHandler.post(new Runnable(this) { // from class: android.support.v4.provider.FontsContractCompat.4.1
                                        final /* synthetic */ AnonymousClass4 this$0;

                                        {
                                            this.this$0 = this;
                                        }

                                        @Override // java.lang.Runnable
                                        public final void run() {
                                            switch (i4) {
                                                case 0:
                                                    ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(-1);
                                                    break;
                                                case 1:
                                                    ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(-2);
                                                    break;
                                                case 2:
                                                    ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(-3);
                                                    break;
                                                case 3:
                                                    ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(-3);
                                                    break;
                                                case 4:
                                                    ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(1);
                                                    break;
                                                case 5:
                                                    ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(-3);
                                                    break;
                                                default:
                                                    ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(-3);
                                                    break;
                                            }
                                        }
                                    });
                                    break;
                                } else {
                                    this.val$callerThreadHandler.post(new Runnable(this) { // from class: android.support.v4.provider.FontsContractCompat.4.1
                                        final /* synthetic */ AnonymousClass4 this$0;

                                        {
                                            this.this$0 = this;
                                        }

                                        @Override // java.lang.Runnable
                                        public final void run() {
                                            switch (i3) {
                                                case 0:
                                                    ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(-1);
                                                    break;
                                                case 1:
                                                    ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(-2);
                                                    break;
                                                case 2:
                                                    ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(-3);
                                                    break;
                                                case 3:
                                                    ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(-3);
                                                    break;
                                                case 4:
                                                    ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(1);
                                                    break;
                                                case 5:
                                                    ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(-3);
                                                    break;
                                                default:
                                                    ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(-3);
                                                    break;
                                            }
                                        }
                                    });
                                    break;
                                }
                            } else {
                                this.val$callerThreadHandler.post(new Runnable(this) { // from class: android.support.v4.provider.FontsContractCompat.4.1
                                    final /* synthetic */ AnonymousClass4 this$0;

                                    {
                                        this.this$0 = this;
                                    }

                                    @Override // java.lang.Runnable
                                    public final void run() {
                                        switch (i) {
                                            case 0:
                                                ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(-1);
                                                break;
                                            case 1:
                                                ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(-2);
                                                break;
                                            case 2:
                                                ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(-3);
                                                break;
                                            case 3:
                                                ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(-3);
                                                break;
                                            case 4:
                                                ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(1);
                                                break;
                                            case 5:
                                                ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(-3);
                                                break;
                                            default:
                                                ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(-3);
                                                break;
                                        }
                                    }
                                });
                                break;
                            }
                        } else {
                            FontInfo[] fonts = fetchFonts.getFonts();
                            if (fonts != null && fonts.length != 0) {
                                for (FontInfo fontInfo : fonts) {
                                    if (fontInfo.getResultCode() != 0) {
                                        final int resultCode = fontInfo.getResultCode();
                                        if (resultCode < 0) {
                                            final int i5 = 5;
                                            this.val$callerThreadHandler.post(new Runnable(this) { // from class: android.support.v4.provider.FontsContractCompat.4.1
                                                final /* synthetic */ AnonymousClass4 this$0;

                                                {
                                                    this.this$0 = this;
                                                }

                                                @Override // java.lang.Runnable
                                                public final void run() {
                                                    switch (i5) {
                                                        case 0:
                                                            ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(-1);
                                                            break;
                                                        case 1:
                                                            ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(-2);
                                                            break;
                                                        case 2:
                                                            ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(-3);
                                                            break;
                                                        case 3:
                                                            ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(-3);
                                                            break;
                                                        case 4:
                                                            ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(1);
                                                            break;
                                                        case 5:
                                                            ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(-3);
                                                            break;
                                                        default:
                                                            ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(-3);
                                                            break;
                                                    }
                                                }
                                            });
                                            break;
                                        } else {
                                            this.val$callerThreadHandler.post(new Runnable() { // from class: android.support.v4.provider.FontsContractCompat.4.7
                                                @Override // java.lang.Runnable
                                                public final void run() {
                                                    ((FontRequestCallback) AnonymousClass4.this.val$callback).onTypefaceRequestFailed(resultCode);
                                                }
                                            });
                                            break;
                                        }
                                    }
                                }
                                final Typeface buildTypeface = FontsContractCompat.buildTypeface((Context) this.val$context, null, fonts);
                                if (buildTypeface == null) {
                                    final int i6 = 6;
                                    this.val$callerThreadHandler.post(new Runnable(this) { // from class: android.support.v4.provider.FontsContractCompat.4.1
                                        final /* synthetic */ AnonymousClass4 this$0;

                                        {
                                            this.this$0 = this;
                                        }

                                        @Override // java.lang.Runnable
                                        public final void run() {
                                            switch (i6) {
                                                case 0:
                                                    ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(-1);
                                                    break;
                                                case 1:
                                                    ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(-2);
                                                    break;
                                                case 2:
                                                    ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(-3);
                                                    break;
                                                case 3:
                                                    ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(-3);
                                                    break;
                                                case 4:
                                                    ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(1);
                                                    break;
                                                case 5:
                                                    ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(-3);
                                                    break;
                                                default:
                                                    ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(-3);
                                                    break;
                                            }
                                        }
                                    });
                                    break;
                                } else {
                                    this.val$callerThreadHandler.post(new Runnable() { // from class: android.support.v4.provider.FontsContractCompat.4.9
                                        @Override // java.lang.Runnable
                                        public final void run() {
                                            switch (i2) {
                                                case 0:
                                                    ((FontRequestCallback) ((AnonymousClass4) this).val$callback).onTypefaceRetrieved((Typeface) buildTypeface);
                                                    break;
                                                default:
                                                    ((SelfDestructiveThread.ReplyCallback) ((AnonymousClass4) this).val$request).onReply(buildTypeface);
                                                    break;
                                            }
                                        }
                                    });
                                    break;
                                }
                            } else {
                                final int i7 = 4;
                                this.val$callerThreadHandler.post(new Runnable(this) { // from class: android.support.v4.provider.FontsContractCompat.4.1
                                    final /* synthetic */ AnonymousClass4 this$0;

                                    {
                                        this.this$0 = this;
                                    }

                                    @Override // java.lang.Runnable
                                    public final void run() {
                                        switch (i7) {
                                            case 0:
                                                ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(-1);
                                                break;
                                            case 1:
                                                ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(-2);
                                                break;
                                            case 2:
                                                ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(-3);
                                                break;
                                            case 3:
                                                ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(-3);
                                                break;
                                            case 4:
                                                ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(1);
                                                break;
                                            case 5:
                                                ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(-3);
                                                break;
                                            default:
                                                ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(-3);
                                                break;
                                        }
                                    }
                                });
                                break;
                            }
                        }
                    } catch (PackageManager.NameNotFoundException unused) {
                        this.val$callerThreadHandler.post(new Runnable(this) { // from class: android.support.v4.provider.FontsContractCompat.4.1
                            final /* synthetic */ AnonymousClass4 this$0;

                            {
                                this.this$0 = this;
                            }

                            @Override // java.lang.Runnable
                            public final void run() {
                                switch (i2) {
                                    case 0:
                                        ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(-1);
                                        break;
                                    case 1:
                                        ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(-2);
                                        break;
                                    case 2:
                                        ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(-3);
                                        break;
                                    case 3:
                                        ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(-3);
                                        break;
                                    case 4:
                                        ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(1);
                                        break;
                                    case 5:
                                        ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(-3);
                                        break;
                                    default:
                                        ((FontRequestCallback) this.this$0.val$callback).onTypefaceRequestFailed(-3);
                                        break;
                                }
                            }
                        });
                    }
                    break;
                default:
                    try {
                        obj = ((Callable) this.val$context).call();
                    } catch (Exception unused2) {
                    }
                    this.val$callerThreadHandler.post(new Runnable() { // from class: android.support.v4.provider.FontsContractCompat.4.9
                        @Override // java.lang.Runnable
                        public final void run() {
                            switch (i) {
                                case 0:
                                    ((FontRequestCallback) ((AnonymousClass4) this).val$callback).onTypefaceRetrieved((Typeface) obj);
                                    break;
                                default:
                                    ((SelfDestructiveThread.ReplyCallback) ((AnonymousClass4) this).val$request).onReply(obj);
                                    break;
                            }
                        }
                    });
                    break;
            }
        }

        public AnonymousClass4(Context context, FontRequest fontRequest, FontRequestCallback fontRequestCallback, Handler handler) {
            this.val$context = context;
            this.val$request = fontRequest;
            this.val$callerThreadHandler = handler;
            this.val$callback = fontRequestCallback;
        }
    }

    public final class Columns implements BaseColumns {
    }

    public class FontFamilyResult {
        private final FontInfo[] mFonts;
        private final int mStatusCode;

        @RestrictTo
        public FontFamilyResult(int i, @Nullable FontInfo[] fontInfoArr) {
            this.mStatusCode = i;
            this.mFonts = fontInfoArr;
        }

        public FontInfo[] getFonts() {
            return this.mFonts;
        }

        public int getStatusCode() {
            return this.mStatusCode;
        }
    }

    public class FontInfo {
        private final boolean mItalic;
        private final int mResultCode;
        private final int mTtcIndex;
        private final Uri mUri;
        private final int mWeight;

        @RestrictTo
        public FontInfo(@NonNull Uri uri, @IntRange int i, @IntRange int i2, boolean z, int i3) {
            this.mUri = (Uri) Preconditions.checkNotNull(uri);
            this.mTtcIndex = i;
            this.mWeight = i2;
            this.mItalic = z;
            this.mResultCode = i3;
        }

        public int getResultCode() {
            return this.mResultCode;
        }

        @IntRange
        public int getTtcIndex() {
            return this.mTtcIndex;
        }

        @NonNull
        public Uri getUri() {
            return this.mUri;
        }

        @IntRange
        public int getWeight() {
            return this.mWeight;
        }

        public boolean isItalic() {
            return this.mItalic;
        }
    }

    public class FontRequestCallback {

        @Retention(RetentionPolicy.SOURCE)
        @RestrictTo
        public @interface FontRequestFailReason {
        }

        public void onTypefaceRequestFailed(int i) {
        }

        public void onTypefaceRetrieved(Typeface typeface) {
        }
    }

    final class TypefaceResult {
        final int mResult;
        final Typeface mTypeface;

        TypefaceResult(Typeface typeface, int i) {
            this.mTypeface = typeface;
            this.mResult = i;
        }
    }

    private FontsContractCompat() {
    }

    @Nullable
    public static Typeface buildTypeface(@NonNull Context context, @Nullable CancellationSignal cancellationSignal, @NonNull FontInfo[] fontInfoArr) {
        return TypefaceCompat.createFromFontInfo(context, cancellationSignal, fontInfoArr, 0);
    }

    @NonNull
    public static FontFamilyResult fetchFonts(@NonNull Context context, @Nullable CancellationSignal cancellationSignal, @NonNull FontRequest fontRequest) {
        ProviderInfo provider = getProvider(context.getPackageManager(), fontRequest, context.getResources());
        Cursor cursor = null;
        if (provider == null) {
            return new FontFamilyResult(1, null);
        }
        String str = provider.authority;
        ArrayList arrayList = new ArrayList();
        Uri build = new Uri.Builder().scheme("content").authority(str).build();
        Uri build2 = new Uri.Builder().scheme("content").authority(str).appendPath("file").build();
        try {
            cursor = context.getContentResolver().query(build, new String[]{"_id", "file_id", "font_ttc_index", "font_variation_settings", "font_weight", "font_italic", "result_code"}, "query = ?", new String[]{fontRequest.getQuery()}, null, cancellationSignal);
            if (cursor != null && cursor.getCount() > 0) {
                int columnIndex = cursor.getColumnIndex("result_code");
                arrayList = new ArrayList();
                int columnIndex2 = cursor.getColumnIndex("_id");
                int columnIndex3 = cursor.getColumnIndex("file_id");
                int columnIndex4 = cursor.getColumnIndex("font_ttc_index");
                int columnIndex5 = cursor.getColumnIndex("font_weight");
                int columnIndex6 = cursor.getColumnIndex("font_italic");
                while (cursor.moveToNext()) {
                    int i = columnIndex != -1 ? cursor.getInt(columnIndex) : 0;
                    arrayList.add(new FontInfo(columnIndex3 == -1 ? ContentUris.withAppendedId(build, cursor.getLong(columnIndex2)) : ContentUris.withAppendedId(build2, cursor.getLong(columnIndex3)), columnIndex4 != -1 ? cursor.getInt(columnIndex4) : 0, columnIndex5 != -1 ? cursor.getInt(columnIndex5) : 400, columnIndex6 != -1 && cursor.getInt(columnIndex6) == 1, i));
                }
            }
            return new FontFamilyResult(0, (FontInfo[]) arrayList.toArray(new FontInfo[0]));
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    static TypefaceResult getFontInternal(Context context, FontRequest fontRequest, int i) {
        try {
            FontFamilyResult fetchFonts = fetchFonts(context, null, fontRequest);
            if (fetchFonts.getStatusCode() != 0) {
                return new TypefaceResult(null, fetchFonts.getStatusCode() == 1 ? -2 : -3);
            }
            Typeface createFromFontInfo = TypefaceCompat.createFromFontInfo(context, null, fetchFonts.getFonts(), i);
            return new TypefaceResult(createFromFontInfo, createFromFontInfo != null ? 0 : -3);
        } catch (PackageManager.NameNotFoundException unused) {
            return new TypefaceResult(null, -1);
        }
    }

    @RestrictTo
    public static Typeface getFontSync(final Context context, final FontRequest fontRequest, @Nullable final ResourcesCompat.FontCallback fontCallback, @Nullable final Handler handler, boolean z, int i, final int i2) {
        final String str = fontRequest.getIdentifier() + "-" + i2;
        Typeface typeface = (Typeface) sTypefaceCache.get(str);
        if (typeface != null) {
            if (fontCallback != null) {
                fontCallback.onFontRetrieved(typeface);
            }
            return typeface;
        }
        if (z && i == -1) {
            TypefaceResult fontInternal = getFontInternal(context, fontRequest, i2);
            if (fontCallback != null) {
                int i3 = fontInternal.mResult;
                if (i3 == 0) {
                    fontCallback.callbackSuccessAsync(fontInternal.mTypeface, handler);
                } else {
                    fontCallback.callbackFailAsync(i3, handler);
                }
            }
            return fontInternal.mTypeface;
        }
        Callable callable = new Callable() { // from class: android.support.v4.provider.FontsContractCompat.1
            @Override // java.util.concurrent.Callable
            public final Object call() {
                TypefaceResult fontInternal2 = FontsContractCompat.getFontInternal(context, fontRequest, i2);
                Typeface typeface2 = fontInternal2.mTypeface;
                if (typeface2 != null) {
                    FontsContractCompat.sTypefaceCache.put(str, typeface2);
                }
                return fontInternal2;
            }
        };
        if (z) {
            try {
                return ((TypefaceResult) sBackgroundThread.postAndWait(callable, i)).mTypeface;
            } catch (InterruptedException unused) {
                return null;
            }
        }
        SelfDestructiveThread.ReplyCallback replyCallback = fontCallback == null ? null : new SelfDestructiveThread.ReplyCallback() { // from class: android.support.v4.provider.FontsContractCompat.2
            @Override // android.support.v4.provider.SelfDestructiveThread.ReplyCallback
            public final void onReply(Object obj) {
                TypefaceResult typefaceResult = (TypefaceResult) obj;
                if (typefaceResult == null) {
                    ResourcesCompat.FontCallback.this.callbackFailAsync(1, handler);
                    return;
                }
                int i4 = typefaceResult.mResult;
                if (i4 == 0) {
                    ResourcesCompat.FontCallback.this.callbackSuccessAsync(typefaceResult.mTypeface, handler);
                } else {
                    ResourcesCompat.FontCallback.this.callbackFailAsync(i4, handler);
                }
            }
        };
        synchronized (sLock) {
            SimpleArrayMap simpleArrayMap = sPendingReplies;
            if (simpleArrayMap.containsKey(str)) {
                if (replyCallback != null) {
                    ((ArrayList) simpleArrayMap.get(str)).add(replyCallback);
                }
                return null;
            }
            if (replyCallback != null) {
                ArrayList arrayList = new ArrayList();
                arrayList.add(replyCallback);
                simpleArrayMap.put(str, arrayList);
            }
            sBackgroundThread.postAndReply(callable, new SelfDestructiveThread.ReplyCallback() { // from class: android.support.v4.provider.FontsContractCompat.3
                @Override // android.support.v4.provider.SelfDestructiveThread.ReplyCallback
                public final void onReply(TypefaceResult typefaceResult) {
                    synchronized (FontsContractCompat.sLock) {
                        SimpleArrayMap simpleArrayMap2 = FontsContractCompat.sPendingReplies;
                        ArrayList arrayList2 = (ArrayList) simpleArrayMap2.get(str);
                        if (arrayList2 == null) {
                            return;
                        }
                        simpleArrayMap2.remove(str);
                        for (int i4 = 0; i4 < arrayList2.size(); i4++) {
                            ((SelfDestructiveThread.ReplyCallback) arrayList2.get(i4)).onReply(typefaceResult);
                        }
                    }
                }
            });
            return null;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:20:0x0092 A[LOOP:1: B:14:0x004f->B:20:0x0092, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:21:0x0091 A[SYNTHETIC] */
    @android.support.annotation.VisibleForTesting
    @android.support.annotation.Nullable
    @android.support.annotation.RestrictTo
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static android.content.pm.ProviderInfo getProvider(@android.support.annotation.NonNull android.content.pm.PackageManager r6, @android.support.annotation.NonNull android.support.v4.provider.FontRequest r7, @android.support.annotation.Nullable android.content.res.Resources r8) {
        /*
            java.lang.String r0 = r7.getProviderAuthority()
            r1 = 0
            android.content.pm.ProviderInfo r2 = r6.resolveContentProvider(r0, r1)
            if (r2 == 0) goto Lba
            java.lang.String r3 = r2.packageName
            java.lang.String r4 = r7.getProviderPackage()
            boolean r3 = r3.equals(r4)
            if (r3 == 0) goto L97
            java.lang.String r0 = r2.packageName
            r3 = 64
            android.content.pm.PackageInfo r6 = r6.getPackageInfo(r0, r3)
            android.content.pm.Signature[] r6 = r6.signatures
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            r3 = 0
        L27:
            int r4 = r6.length
            if (r3 >= r4) goto L36
            r4 = r6[r3]
            byte[] r4 = r4.toByteArray()
            r0.add(r4)
            int r3 = r3 + 1
            goto L27
        L36:
            java.util.Comparator r6 = android.support.v4.provider.FontsContractCompat.sByteArrayComparator
            java.util.Collections.sort(r0, r6)
            java.util.List r6 = r7.getCertificates()
            if (r6 == 0) goto L46
            java.util.List r6 = r7.getCertificates()
            goto L4e
        L46:
            int r6 = r7.getCertificatesArrayResId()
            java.util.List r6 = android.support.v4.content.res.FontResourcesParserCompat.readCerts(r8, r6)
        L4e:
            r7 = 0
        L4f:
            int r8 = r6.size()
            if (r7 >= r8) goto L95
            java.util.ArrayList r8 = new java.util.ArrayList
            java.lang.Object r3 = r6.get(r7)
            java.util.Collection r3 = (java.util.Collection) r3
            r8.<init>(r3)
            java.util.Comparator r3 = android.support.v4.provider.FontsContractCompat.sByteArrayComparator
            java.util.Collections.sort(r8, r3)
            int r3 = r0.size()
            int r4 = r8.size()
            if (r3 == r4) goto L71
        L6f:
            r8 = 0
            goto L8f
        L71:
            r3 = 0
        L72:
            int r4 = r0.size()
            if (r3 >= r4) goto L8e
            java.lang.Object r4 = r0.get(r3)
            byte[] r4 = (byte[]) r4
            java.lang.Object r5 = r8.get(r3)
            byte[] r5 = (byte[]) r5
            boolean r4 = java.util.Arrays.equals(r4, r5)
            if (r4 != 0) goto L8b
            goto L6f
        L8b:
            int r3 = r3 + 1
            goto L72
        L8e:
            r8 = 1
        L8f:
            if (r8 == 0) goto L92
            return r2
        L92:
            int r7 = r7 + 1
            goto L4f
        L95:
            r6 = 0
            return r6
        L97:
            android.content.pm.PackageManager$NameNotFoundException r6 = new android.content.pm.PackageManager$NameNotFoundException
            java.lang.StringBuilder r8 = new java.lang.StringBuilder
            r8.<init>()
            java.lang.String r1 = "Found content provider "
            r8.append(r1)
            r8.append(r0)
            java.lang.String r0 = ", but package was not "
            r8.append(r0)
            java.lang.String r7 = r7.getProviderPackage()
            r8.append(r7)
            java.lang.String r7 = r8.toString()
            r6.<init>(r7)
            throw r6
        Lba:
            android.content.pm.PackageManager$NameNotFoundException r6 = new android.content.pm.PackageManager$NameNotFoundException
            java.lang.StringBuilder r7 = new java.lang.StringBuilder
            r7.<init>()
            java.lang.String r8 = "No package found for authority: "
            r7.append(r8)
            r7.append(r0)
            java.lang.String r7 = r7.toString()
            r6.<init>(r7)
            throw r6
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.provider.FontsContractCompat.getProvider(android.content.pm.PackageManager, android.support.v4.provider.FontRequest, android.content.res.Resources):android.content.pm.ProviderInfo");
    }

    @RequiresApi
    @RestrictTo
    public static Map prepareFontData(Context context, FontInfo[] fontInfoArr, CancellationSignal cancellationSignal) {
        HashMap hashMap = new HashMap();
        for (FontInfo fontInfo : fontInfoArr) {
            if (fontInfo.getResultCode() == 0) {
                Uri uri = fontInfo.getUri();
                if (!hashMap.containsKey(uri)) {
                    hashMap.put(uri, TypefaceCompatUtil.mmap(context, cancellationSignal, uri));
                }
            }
        }
        return Collections.unmodifiableMap(hashMap);
    }

    public static void requestFont(@NonNull Context context, @NonNull FontRequest fontRequest, @NonNull FontRequestCallback fontRequestCallback, @NonNull Handler handler) {
        handler.post(new AnonymousClass4(context, fontRequest, fontRequestCallback, new Handler()));
    }

    @RestrictTo
    public static void resetCache() {
        sTypefaceCache.evictAll();
    }
}
