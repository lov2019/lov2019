package android.support.v4.app;

/* loaded from: classes.dex */
public final class NotificationCompatExtras {
    private NotificationCompatExtras() {
    }
}
