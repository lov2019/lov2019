package android.support.v4.widget;

import android.content.Context;
import android.os.SystemClock;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.view.ViewCompat;
import android.support.v4.widget.AutoScrollHelper;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.ProgressBar;

/* loaded from: classes.dex */
public class ContentLoadingProgressBar extends ProgressBar {
    private final Runnable mDelayedHide;
    private final Runnable mDelayedShow;
    boolean mDismissed;
    boolean mPostedHide;
    boolean mPostedShow;
    long mStartTime;

    /* renamed from: android.support.v4.widget.ContentLoadingProgressBar$1, reason: invalid class name */
    final class AnonymousClass1 implements Runnable {
        public final /* synthetic */ int $r8$classId;
        final /* synthetic */ Object this$0;

        public /* synthetic */ AnonymousClass1(int i, Object obj) {
            this.$r8$classId = i;
            this.this$0 = obj;
        }

        @Override // java.lang.Runnable
        public final void run() {
            switch (this.$r8$classId) {
                case 0:
                    ContentLoadingProgressBar contentLoadingProgressBar = (ContentLoadingProgressBar) this.this$0;
                    contentLoadingProgressBar.mPostedHide = false;
                    contentLoadingProgressBar.mStartTime = -1L;
                    contentLoadingProgressBar.setVisibility(8);
                    break;
                case 1:
                    ContentLoadingProgressBar contentLoadingProgressBar2 = (ContentLoadingProgressBar) this.this$0;
                    contentLoadingProgressBar2.mPostedShow = false;
                    if (!contentLoadingProgressBar2.mDismissed) {
                        contentLoadingProgressBar2.mStartTime = System.currentTimeMillis();
                        ((ContentLoadingProgressBar) this.this$0).setVisibility(0);
                        break;
                    }
                    break;
                default:
                    AutoScrollHelper autoScrollHelper = (AutoScrollHelper) this.this$0;
                    if (autoScrollHelper.mAnimating) {
                        if (autoScrollHelper.mNeedsReset) {
                            autoScrollHelper.mNeedsReset = false;
                            autoScrollHelper.mScroller.start();
                        }
                        AutoScrollHelper.ClampedScroller clampedScroller = ((AutoScrollHelper) this.this$0).mScroller;
                        if (!clampedScroller.isFinished() && ((AutoScrollHelper) this.this$0).shouldAnimate()) {
                            AutoScrollHelper autoScrollHelper2 = (AutoScrollHelper) this.this$0;
                            if (autoScrollHelper2.mNeedsCancel) {
                                autoScrollHelper2.mNeedsCancel = false;
                                long uptimeMillis = SystemClock.uptimeMillis();
                                MotionEvent obtain = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
                                autoScrollHelper2.mTarget.onTouchEvent(obtain);
                                obtain.recycle();
                            }
                            clampedScroller.computeScrollDelta();
                            ((AutoScrollHelper) this.this$0).scrollTargetBy(clampedScroller.getDeltaX(), clampedScroller.getDeltaY());
                            ViewCompat.postOnAnimation(((AutoScrollHelper) this.this$0).mTarget, this);
                            break;
                        } else {
                            ((AutoScrollHelper) this.this$0).mAnimating = false;
                            break;
                        }
                    }
                    break;
            }
        }
    }

    public ContentLoadingProgressBar(@NonNull Context context) {
        this(context, null);
    }

    public synchronized void hide() {
        this.mDismissed = true;
        removeCallbacks(this.mDelayedShow);
        this.mPostedShow = false;
        long currentTimeMillis = System.currentTimeMillis();
        long j = this.mStartTime;
        long j2 = currentTimeMillis - j;
        if (j2 < 500 && j != -1) {
            if (!this.mPostedHide) {
                postDelayed(this.mDelayedHide, 500 - j2);
                this.mPostedHide = true;
            }
        }
        setVisibility(8);
    }

    @Override // android.widget.ProgressBar, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        removeCallbacks(this.mDelayedHide);
        removeCallbacks(this.mDelayedShow);
    }

    @Override // android.widget.ProgressBar, android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(this.mDelayedHide);
        removeCallbacks(this.mDelayedShow);
    }

    public synchronized void show() {
        this.mStartTime = -1L;
        this.mDismissed = false;
        removeCallbacks(this.mDelayedHide);
        this.mPostedHide = false;
        if (!this.mPostedShow) {
            postDelayed(this.mDelayedShow, 500L);
            this.mPostedShow = true;
        }
    }

    public ContentLoadingProgressBar(@NonNull Context context, @Nullable AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        this.mStartTime = -1L;
        this.mPostedHide = false;
        this.mPostedShow = false;
        this.mDismissed = false;
        this.mDelayedHide = new AnonymousClass1(0, this);
        this.mDelayedShow = new AnonymousClass1(1, this);
    }
}
