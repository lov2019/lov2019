package android.support.multidex;

import android.arch.core.internal.SafeIterableMap$$ExternalSyntheticOutline0;
import java.io.RandomAccessFile;
import java.util.zip.ZipException;

/* loaded from: classes.dex */
abstract class ZipUtil {

    final class CentralDirectory {
        long offset;
        long size;

        CentralDirectory() {
        }
    }

    static CentralDirectory findCentralDirectory(RandomAccessFile randomAccessFile) {
        long length = randomAccessFile.length() - 22;
        if (length < 0) {
            StringBuilder m = SafeIterableMap$$ExternalSyntheticOutline0.m("File too short to be a zip file: ");
            m.append(randomAccessFile.length());
            throw new ZipException(m.toString());
        }
        long j = length - 65536;
        long j2 = j >= 0 ? j : 0L;
        int reverseBytes = Integer.reverseBytes(101010256);
        do {
            randomAccessFile.seek(length);
            if (randomAccessFile.readInt() == reverseBytes) {
                randomAccessFile.skipBytes(2);
                randomAccessFile.skipBytes(2);
                randomAccessFile.skipBytes(2);
                randomAccessFile.skipBytes(2);
                CentralDirectory centralDirectory = new CentralDirectory();
                centralDirectory.size = Integer.reverseBytes(randomAccessFile.readInt()) & 4294967295L;
                centralDirectory.offset = Integer.reverseBytes(randomAccessFile.readInt()) & 4294967295L;
                return centralDirectory;
            }
            length--;
        } while (length >= j2);
        throw new ZipException("End Of Central Directory signature not found");
    }
}
