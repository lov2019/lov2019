package android.support.multidex;

import android.arch.core.internal.SafeIterableMap$$ExternalSyntheticOutline0;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.support.multidex.ZipUtil;
import android.util.Log;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileFilter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

/* loaded from: classes.dex */
abstract class MultiDexExtractor {
    private static Method sApplyMethod;

    static {
        try {
            sApplyMethod = SharedPreferences.Editor.class.getMethod("apply", new Class[0]);
        } catch (NoSuchMethodException unused) {
            sApplyMethod = null;
        }
    }

    private static void extract(ZipFile zipFile, ZipEntry zipEntry, File file, String str) {
        InputStream inputStream = zipFile.getInputStream(zipEntry);
        File createTempFile = File.createTempFile(str, ".zip", file.getParentFile());
        StringBuilder m = SafeIterableMap$$ExternalSyntheticOutline0.m("Extracting ");
        m.append(createTempFile.getPath());
        Log.i("MultiDex", m.toString());
        try {
            ZipOutputStream zipOutputStream = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(createTempFile)));
            try {
                ZipEntry zipEntry2 = new ZipEntry("classes.dex");
                zipEntry2.setTime(zipEntry.getTime());
                zipOutputStream.putNextEntry(zipEntry2);
                byte[] bArr = new byte[16384];
                for (int read = inputStream.read(bArr); read != -1; read = inputStream.read(bArr)) {
                    zipOutputStream.write(bArr, 0, read);
                }
                zipOutputStream.closeEntry();
                zipOutputStream.close();
                Log.i("MultiDex", "Renaming to " + file.getPath());
                if (createTempFile.renameTo(file)) {
                    return;
                }
                throw new IOException("Failed to rename \"" + createTempFile.getAbsolutePath() + "\" to \"" + file.getAbsolutePath() + "\"");
            } catch (Throwable th) {
                zipOutputStream.close();
                throw th;
            }
        } finally {
            try {
                inputStream.close();
            } catch (IOException e) {
                Log.w("MultiDex", "Failed to close resource", e);
            }
            createTempFile.delete();
        }
    }

    static ArrayList load(Context context, ApplicationInfo applicationInfo, File file, boolean z) {
        ArrayList performExtractions;
        StringBuilder m = SafeIterableMap$$ExternalSyntheticOutline0.m("MultiDexExtractor.load(");
        m.append(applicationInfo.sourceDir);
        m.append(", ");
        m.append(z);
        m.append(")");
        Log.i("MultiDex", m.toString());
        File file2 = new File(applicationInfo.sourceDir);
        RandomAccessFile randomAccessFile = new RandomAccessFile(file2, "r");
        try {
            ZipUtil.CentralDirectory findCentralDirectory = ZipUtil.findCentralDirectory(randomAccessFile);
            CRC32 crc32 = new CRC32();
            long j = findCentralDirectory.size;
            randomAccessFile.seek(findCentralDirectory.offset);
            byte[] bArr = new byte[16384];
            int read = randomAccessFile.read(bArr, 0, (int) Math.min(16384L, j));
            while (read != -1) {
                crc32.update(bArr, 0, read);
                j -= read;
                if (j == 0) {
                    break;
                }
                read = randomAccessFile.read(bArr, 0, (int) Math.min(16384L, j));
            }
            long value = crc32.getValue();
            randomAccessFile.close();
            if (value == -1) {
                value--;
            }
            if (!z) {
                SharedPreferences sharedPreferences = context.getSharedPreferences("multidex.version", 4);
                long j2 = sharedPreferences.getLong("timestamp", -1L);
                long lastModified = file2.lastModified();
                if (lastModified == -1) {
                    lastModified--;
                }
                if (!((j2 == lastModified && sharedPreferences.getLong("crc", -1L) == value) ? false : true)) {
                    try {
                        performExtractions = loadExistingExtractions(context, file2, file);
                    } catch (IOException e) {
                        Log.w("MultiDex", "Failed to reload existing extracted secondary dex files, falling back to fresh extraction", e);
                        performExtractions = performExtractions(file2, file);
                        long lastModified2 = file2.lastModified();
                        if (lastModified2 == -1) {
                            lastModified2--;
                        }
                        putStoredApkInfo(context, lastModified2, value, performExtractions.size() + 1);
                    }
                    StringBuilder m2 = SafeIterableMap$$ExternalSyntheticOutline0.m("load found ");
                    m2.append(performExtractions.size());
                    m2.append(" secondary dex files");
                    Log.i("MultiDex", m2.toString());
                    return performExtractions;
                }
            }
            Log.i("MultiDex", "Detected that extraction must be performed.");
            performExtractions = performExtractions(file2, file);
            long lastModified3 = file2.lastModified();
            if (lastModified3 == -1) {
                lastModified3--;
            }
            putStoredApkInfo(context, lastModified3, value, performExtractions.size() + 1);
            StringBuilder m22 = SafeIterableMap$$ExternalSyntheticOutline0.m("load found ");
            m22.append(performExtractions.size());
            m22.append(" secondary dex files");
            Log.i("MultiDex", m22.toString());
            return performExtractions;
        } catch (Throwable th) {
            randomAccessFile.close();
            throw th;
        }
    }

    private static ArrayList loadExistingExtractions(Context context, File file, File file2) {
        Log.i("MultiDex", "loading existing secondary dex files");
        String str = file.getName() + ".classes";
        int i = context.getSharedPreferences("multidex.version", 4).getInt("dex.number", 1);
        ArrayList arrayList = new ArrayList(i);
        for (int i2 = 2; i2 <= i; i2++) {
            File file3 = new File(file2, str + i2 + ".zip");
            if (!file3.isFile()) {
                StringBuilder m = SafeIterableMap$$ExternalSyntheticOutline0.m("Missing extracted secondary dex file '");
                m.append(file3.getPath());
                m.append("'");
                throw new IOException(m.toString());
            }
            arrayList.add(file3);
            if (!verifyZipFile(file3)) {
                Log.i("MultiDex", "Invalid zip file: " + file3);
                throw new IOException("Invalid ZIP file.");
            }
        }
        return arrayList;
    }

    private static void mkdirChecked(File file) {
        file.mkdir();
        if (file.isDirectory()) {
            return;
        }
        File parentFile = file.getParentFile();
        if (parentFile == null) {
            StringBuilder m = SafeIterableMap$$ExternalSyntheticOutline0.m("Failed to create dir ");
            m.append(file.getPath());
            m.append(". Parent file is null.");
            Log.e("MultiDex", m.toString());
        } else {
            StringBuilder m2 = SafeIterableMap$$ExternalSyntheticOutline0.m("Failed to create dir ");
            m2.append(file.getPath());
            m2.append(". parent file is a dir ");
            m2.append(parentFile.isDirectory());
            m2.append(", a file ");
            m2.append(parentFile.isFile());
            m2.append(", exists ");
            m2.append(parentFile.exists());
            m2.append(", readable ");
            m2.append(parentFile.canRead());
            m2.append(", writable ");
            m2.append(parentFile.canWrite());
            Log.e("MultiDex", m2.toString());
        }
        StringBuilder m3 = SafeIterableMap$$ExternalSyntheticOutline0.m("Failed to create cache directory ");
        m3.append(file.getPath());
        throw new IOException(m3.toString());
    }

    private static ArrayList performExtractions(File file, File file2) {
        final String str = file.getName() + ".classes";
        mkdirChecked(file2.getParentFile());
        mkdirChecked(file2);
        File[] listFiles = file2.listFiles(new FileFilter() { // from class: android.support.multidex.MultiDexExtractor.1
            @Override // java.io.FileFilter
            public final boolean accept(File file3) {
                return !file3.getName().startsWith(str);
            }
        });
        if (listFiles == null) {
            StringBuilder m = SafeIterableMap$$ExternalSyntheticOutline0.m("Failed to list secondary dex dir content (");
            m.append(file2.getPath());
            m.append(").");
            Log.w("MultiDex", m.toString());
        } else {
            for (File file3 : listFiles) {
                StringBuilder m2 = SafeIterableMap$$ExternalSyntheticOutline0.m("Trying to delete old file ");
                m2.append(file3.getPath());
                m2.append(" of size ");
                m2.append(file3.length());
                Log.i("MultiDex", m2.toString());
                if (file3.delete()) {
                    StringBuilder m3 = SafeIterableMap$$ExternalSyntheticOutline0.m("Deleted old file ");
                    m3.append(file3.getPath());
                    Log.i("MultiDex", m3.toString());
                } else {
                    StringBuilder m4 = SafeIterableMap$$ExternalSyntheticOutline0.m("Failed to delete old file ");
                    m4.append(file3.getPath());
                    Log.w("MultiDex", m4.toString());
                }
            }
        }
        ArrayList arrayList = new ArrayList();
        ZipFile zipFile = new ZipFile(file);
        int i = 2;
        try {
            ZipEntry entry = zipFile.getEntry("classes2.dex");
            while (entry != null) {
                File file4 = new File(file2, str + i + ".zip");
                arrayList.add(file4);
                Log.i("MultiDex", "Extraction is needed for file " + file4);
                int i2 = 0;
                boolean z = false;
                while (i2 < 3 && !z) {
                    i2++;
                    extract(zipFile, entry, file4, str);
                    z = verifyZipFile(file4);
                    StringBuilder sb = new StringBuilder();
                    sb.append("Extraction ");
                    sb.append(z ? "success" : "failed");
                    sb.append(" - length ");
                    sb.append(file4.getAbsolutePath());
                    sb.append(": ");
                    sb.append(file4.length());
                    Log.i("MultiDex", sb.toString());
                    if (!z) {
                        file4.delete();
                        if (file4.exists()) {
                            Log.w("MultiDex", "Failed to delete corrupted secondary dex '" + file4.getPath() + "'");
                        }
                    }
                }
                if (!z) {
                    throw new IOException("Could not create zip file " + file4.getAbsolutePath() + " for secondary dex (" + i + ")");
                }
                i++;
                entry = zipFile.getEntry("classes" + i + ".dex");
            }
            return arrayList;
        } finally {
            try {
                zipFile.close();
            } catch (IOException e) {
                Log.w("MultiDex", "Failed to close resource", e);
            }
        }
    }

    private static void putStoredApkInfo(Context context, long j, long j2, int i) {
        SharedPreferences.Editor edit = context.getSharedPreferences("multidex.version", 4).edit();
        edit.putLong("timestamp", j);
        edit.putLong("crc", j2);
        edit.putInt("dex.number", i);
        Method method = sApplyMethod;
        if (method != null) {
            try {
                method.invoke(edit, new Object[0]);
                return;
            } catch (IllegalAccessException | InvocationTargetException unused) {
            }
        }
        edit.commit();
    }

    static boolean verifyZipFile(File file) {
        try {
            try {
                new ZipFile(file).close();
                return true;
            } catch (IOException unused) {
                Log.w("MultiDex", "Failed to close zip file: " + file.getAbsolutePath());
                return false;
            }
        } catch (ZipException e) {
            StringBuilder m = SafeIterableMap$$ExternalSyntheticOutline0.m("File ");
            m.append(file.getAbsolutePath());
            m.append(" is not a valid zip file.");
            Log.w("MultiDex", m.toString(), e);
            return false;
        } catch (IOException e2) {
            StringBuilder m2 = SafeIterableMap$$ExternalSyntheticOutline0.m("Got an IOException trying to open zip file: ");
            m2.append(file.getAbsolutePath());
            Log.w("MultiDex", m2.toString(), e2);
            return false;
        }
    }
}
