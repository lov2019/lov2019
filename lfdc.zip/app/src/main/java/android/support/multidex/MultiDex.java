package android.support.multidex;

import android.arch.core.internal.SafeIterableMap$$ExternalSyntheticOutline0;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Log;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;

/* loaded from: classes.dex */
public abstract class MultiDex {
    private static final boolean IS_VM_MULTIDEX_CAPABLE;
    private static final String SECONDARY_FOLDER_NAME;
    private static final HashSet installedApk;

    /* JADX WARN: Code restructure failed: missing block: B:9:0x004b, code lost:
    
        if (r2 < 1) goto L11;
     */
    /* JADX WARN: Removed duplicated region for block: B:12:0x005e  */
    /* JADX WARN: Removed duplicated region for block: B:16:0x0061  */
    static {
        /*
            java.lang.String r0 = "code_cache"
            java.lang.StringBuilder r0 = android.arch.core.internal.SafeIterableMap$$ExternalSyntheticOutline0.m(r0)
            java.lang.String r1 = java.io.File.separator
            r0.append(r1)
            java.lang.String r1 = "secondary-dexes"
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            android.support.multidex.MultiDex.SECONDARY_FOLDER_NAME = r0
            java.util.HashSet r0 = new java.util.HashSet
            r0.<init>()
            android.support.multidex.MultiDex.installedApk = r0
            java.lang.String r0 = "java.vm.version"
            java.lang.String r0 = java.lang.System.getProperty(r0)
            r1 = 1
            if (r0 == 0) goto L4e
            java.lang.String r2 = "(\\d+)\\.(\\d+)(\\.\\d+)?"
            java.util.regex.Pattern r2 = java.util.regex.Pattern.compile(r2)
            java.util.regex.Matcher r2 = r2.matcher(r0)
            boolean r3 = r2.matches()
            if (r3 == 0) goto L4e
            java.lang.String r3 = r2.group(r1)     // Catch: java.lang.NumberFormatException -> L4e
            int r3 = java.lang.Integer.parseInt(r3)     // Catch: java.lang.NumberFormatException -> L4e
            r4 = 2
            java.lang.String r2 = r2.group(r4)     // Catch: java.lang.NumberFormatException -> L4e
            int r2 = java.lang.Integer.parseInt(r2)     // Catch: java.lang.NumberFormatException -> L4e
            if (r3 > r4) goto L4f
            if (r3 != r4) goto L4e
            if (r2 < r1) goto L4e
            goto L4f
        L4e:
            r1 = 0
        L4f:
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            java.lang.String r3 = "VM with version "
            r2.append(r3)
            r2.append(r0)
            if (r1 == 0) goto L61
            java.lang.String r0 = " has multidex support"
            goto L63
        L61:
            java.lang.String r0 = " does not have multidex support"
        L63:
            r2.append(r0)
            java.lang.String r0 = r2.toString()
            java.lang.String r2 = "MultiDex"
            android.util.Log.i(r2, r0)
            android.support.multidex.MultiDex.IS_VM_MULTIDEX_CAPABLE = r1
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.multidex.MultiDex.<clinit>():void");
    }

    static void access$400(Object obj, String str, Object[] objArr) {
        Field findField = findField(str, obj);
        Object[] objArr2 = (Object[]) findField.get(obj);
        Object[] objArr3 = (Object[]) Array.newInstance(objArr2.getClass().getComponentType(), objArr2.length + objArr.length);
        System.arraycopy(objArr2, 0, objArr3, 0, objArr2.length);
        System.arraycopy(objArr, 0, objArr3, objArr2.length, objArr.length);
        findField.set(obj, objArr3);
    }

    private static void clearOldDexDir(Context context) {
        File file = new File(context.getFilesDir(), "secondary-dexes");
        if (file.isDirectory()) {
            StringBuilder m = SafeIterableMap$$ExternalSyntheticOutline0.m("Clearing old secondary dex dir (");
            m.append(file.getPath());
            m.append(").");
            Log.i("MultiDex", m.toString());
            File[] listFiles = file.listFiles();
            if (listFiles == null) {
                StringBuilder m2 = SafeIterableMap$$ExternalSyntheticOutline0.m("Failed to list secondary dex dir content (");
                m2.append(file.getPath());
                m2.append(").");
                Log.w("MultiDex", m2.toString());
                return;
            }
            for (File file2 : listFiles) {
                StringBuilder m3 = SafeIterableMap$$ExternalSyntheticOutline0.m("Trying to delete old file ");
                m3.append(file2.getPath());
                m3.append(" of size ");
                m3.append(file2.length());
                Log.i("MultiDex", m3.toString());
                if (file2.delete()) {
                    StringBuilder m4 = SafeIterableMap$$ExternalSyntheticOutline0.m("Deleted old file ");
                    m4.append(file2.getPath());
                    Log.i("MultiDex", m4.toString());
                } else {
                    StringBuilder m5 = SafeIterableMap$$ExternalSyntheticOutline0.m("Failed to delete old file ");
                    m5.append(file2.getPath());
                    Log.w("MultiDex", m5.toString());
                }
            }
            if (file.delete()) {
                StringBuilder m6 = SafeIterableMap$$ExternalSyntheticOutline0.m("Deleted old secondary dex dir ");
                m6.append(file.getPath());
                Log.i("MultiDex", m6.toString());
            } else {
                StringBuilder m7 = SafeIterableMap$$ExternalSyntheticOutline0.m("Failed to delete secondary dex dir ");
                m7.append(file.getPath());
                Log.w("MultiDex", m7.toString());
            }
        }
    }

    private static Field findField(String str, Object obj) {
        for (Class<?> cls = obj.getClass(); cls != null; cls = cls.getSuperclass()) {
            try {
                Field declaredField = cls.getDeclaredField(str);
                if (!declaredField.isAccessible()) {
                    declaredField.setAccessible(true);
                }
                return declaredField;
            } catch (NoSuchFieldException unused) {
            }
        }
        throw new NoSuchFieldException("Field " + str + " not found in " + obj.getClass());
    }

    public static void install(Context context) {
        boolean z;
        Log.i("MultiDex", "install");
        if (IS_VM_MULTIDEX_CAPABLE) {
            Log.i("MultiDex", "VM has multidex support, MultiDex support library is disabled.");
            return;
        }
        ApplicationInfo applicationInfo = null;
        try {
            try {
                PackageManager packageManager = context.getPackageManager();
                String packageName = context.getPackageName();
                if (packageManager != null && packageName != null) {
                    applicationInfo = packageManager.getApplicationInfo(packageName, 128);
                }
            } catch (RuntimeException e) {
                Log.w("MultiDex", "Failure while trying to obtain ApplicationInfo from Context. Must be running in test mode. Skip patching.", e);
            }
            if (applicationInfo == null) {
                return;
            }
            HashSet hashSet = installedApk;
            synchronized (hashSet) {
                String str = applicationInfo.sourceDir;
                if (hashSet.contains(str)) {
                    return;
                }
                hashSet.add(str);
                Log.w("MultiDex", "MultiDex is not guaranteed to work in SDK version " + Build.VERSION.SDK_INT + ": SDK version higher than 20 should be backed by runtime with built-in multidex capabilty but it's not the case here: java.vm.version=\"" + System.getProperty("java.vm.version") + "\"");
                try {
                    ClassLoader classLoader = context.getClassLoader();
                    if (classLoader == null) {
                        Log.e("MultiDex", "Context class loader is null. Must be running in test mode. Skip patching.");
                        return;
                    }
                    try {
                        clearOldDexDir(context);
                    } catch (Throwable th) {
                        Log.w("MultiDex", "Something went wrong when trying to clear old MultiDex extraction, continuing without cleaning.", th);
                    }
                    File file = new File(applicationInfo.dataDir, SECONDARY_FOLDER_NAME);
                    boolean z2 = false;
                    ArrayList load = MultiDexExtractor.load(context, applicationInfo, file, false);
                    Iterator it = load.iterator();
                    while (true) {
                        if (!it.hasNext()) {
                            z = true;
                            break;
                        } else if (!MultiDexExtractor.verifyZipFile((File) it.next())) {
                            z = false;
                            break;
                        }
                    }
                    if (z) {
                        installSecondaryDexes(file, classLoader, load);
                    } else {
                        Log.w("MultiDex", "Files were not valid zip files.  Forcing a reload.");
                        ArrayList load2 = MultiDexExtractor.load(context, applicationInfo, file, true);
                        Iterator it2 = load2.iterator();
                        while (true) {
                            if (!it2.hasNext()) {
                                z2 = true;
                                break;
                            } else if (!MultiDexExtractor.verifyZipFile((File) it2.next())) {
                                break;
                            }
                        }
                        if (!z2) {
                            throw new RuntimeException("Zip files were not valid.");
                        }
                        installSecondaryDexes(file, classLoader, load2);
                    }
                    Log.i("MultiDex", "install done");
                } catch (RuntimeException e2) {
                    Log.w("MultiDex", "Failure while trying to obtain Context class loader. Must be running in test mode. Skip patching.", e2);
                }
            }
        } catch (Exception e3) {
            Log.e("MultiDex", "Multidex installation failure", e3);
            StringBuilder m = SafeIterableMap$$ExternalSyntheticOutline0.m("Multi dex installation failed (");
            m.append(e3.getMessage());
            m.append(").");
            throw new RuntimeException(m.toString());
        }
    }

    private static void installSecondaryDexes(File file, ClassLoader classLoader, ArrayList arrayList) {
        IOException[] iOExceptionArr;
        if (arrayList.isEmpty()) {
            return;
        }
        Object obj = findField("pathList", classLoader).get(classLoader);
        ArrayList arrayList2 = new ArrayList();
        ArrayList arrayList3 = new ArrayList(arrayList);
        Class<?>[] clsArr = {ArrayList.class, File.class, ArrayList.class};
        for (Class<?> cls = obj.getClass(); cls != null; cls = cls.getSuperclass()) {
            try {
                Method declaredMethod = cls.getDeclaredMethod("makeDexElements", clsArr);
                if (!declaredMethod.isAccessible()) {
                    declaredMethod.setAccessible(true);
                }
                access$400(obj, "dexElements", (Object[]) declaredMethod.invoke(obj, arrayList3, file, arrayList2));
                if (arrayList2.size() > 0) {
                    Iterator it = arrayList2.iterator();
                    while (it.hasNext()) {
                        Log.w("MultiDex", "Exception in makeDexElement", (IOException) it.next());
                    }
                    Field findField = findField("dexElementsSuppressedExceptions", classLoader);
                    IOException[] iOExceptionArr2 = (IOException[]) findField.get(classLoader);
                    if (iOExceptionArr2 == null) {
                        iOExceptionArr = (IOException[]) arrayList2.toArray(new IOException[arrayList2.size()]);
                    } else {
                        IOException[] iOExceptionArr3 = new IOException[arrayList2.size() + iOExceptionArr2.length];
                        arrayList2.toArray(iOExceptionArr3);
                        System.arraycopy(iOExceptionArr2, 0, iOExceptionArr3, arrayList2.size(), iOExceptionArr2.length);
                        iOExceptionArr = iOExceptionArr3;
                    }
                    findField.set(classLoader, iOExceptionArr);
                    return;
                }
                return;
            } catch (NoSuchMethodException unused) {
            }
        }
        throw new NoSuchMethodException("Method makeDexElements with parameters " + Arrays.asList(clsArr) + " not found in " + obj.getClass());
    }
}
