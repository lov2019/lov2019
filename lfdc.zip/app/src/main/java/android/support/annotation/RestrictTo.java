package android.support.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.ANNOTATION_TYPE, ElementType.TYPE, ElementType.METHOD, ElementType.CONSTRUCTOR, ElementType.FIELD, ElementType.PACKAGE})
@Retention(RetentionPolicy.CLASS)
/* loaded from: classes.dex */
public @interface RestrictTo {

    public enum Scope {
        /* JADX INFO: Fake field, exist only in values array */
        EF5,
        /* JADX INFO: Fake field, exist only in values array */
        EF13,
        /* JADX INFO: Fake field, exist only in values array */
        EF21,
        /* JADX INFO: Fake field, exist only in values array */
        EF29,
        /* JADX INFO: Fake field, exist only in values array */
        EF37;

        Scope() {
        }
    }
}
