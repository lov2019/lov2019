package android.support.compat;

import android.R;

/* loaded from: classes.dex */
public abstract class R$styleable {
    public static final int[] ColorStateListItem = {R.attr.color, R.attr.alpha, com.candy.survivalcraftAPI_Net_2_3.R.attr.alpha};
    public static final int[] FontFamily = {com.candy.survivalcraftAPI_Net_2_3.R.attr.fontProviderAuthority, com.candy.survivalcraftAPI_Net_2_3.R.attr.fontProviderPackage, com.candy.survivalcraftAPI_Net_2_3.R.attr.fontProviderQuery, com.candy.survivalcraftAPI_Net_2_3.R.attr.fontProviderCerts, com.candy.survivalcraftAPI_Net_2_3.R.attr.fontProviderFetchStrategy, com.candy.survivalcraftAPI_Net_2_3.R.attr.fontProviderFetchTimeout};
    public static final int[] FontFamilyFont = {R.attr.font, R.attr.fontWeight, R.attr.fontStyle, R.attr.ttcIndex, R.attr.fontVariationSettings, com.candy.survivalcraftAPI_Net_2_3.R.attr.fontStyle, com.candy.survivalcraftAPI_Net_2_3.R.attr.font, com.candy.survivalcraftAPI_Net_2_3.R.attr.fontWeight, com.candy.survivalcraftAPI_Net_2_3.R.attr.fontVariationSettings, com.candy.survivalcraftAPI_Net_2_3.R.attr.ttcIndex};
    public static final int[] GradientColor = {R.attr.startColor, R.attr.endColor, R.attr.type, R.attr.centerX, R.attr.centerY, R.attr.gradientRadius, R.attr.tileMode, R.attr.centerColor, R.attr.startX, R.attr.startY, R.attr.endX, R.attr.endY};
    public static final int[] GradientColorItem = {R.attr.color, R.attr.offset};
}
