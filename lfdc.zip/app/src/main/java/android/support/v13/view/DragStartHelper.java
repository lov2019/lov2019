package android.support.v13.view;

import android.graphics.Point;
import android.view.MotionEvent;
import android.view.View;

/* loaded from: classes.dex */
public class DragStartHelper {
    private boolean mDragging;
    private int mLastTouchX;
    private int mLastTouchY;
    private final OnDragStartListener mListener;
    private final View.OnLongClickListener mLongClickListener = new View.OnLongClickListener() { // from class: android.support.v13.view.DragStartHelper.1
        @Override // android.view.View.OnLongClickListener
        public final boolean onLongClick(View view) {
            return DragStartHelper.this.onLongClick(view);
        }
    };
    private final View.OnTouchListener mTouchListener = new View.OnTouchListener() { // from class: android.support.v13.view.DragStartHelper.2
        @Override // android.view.View.OnTouchListener
        public final boolean onTouch(View view, MotionEvent motionEvent) {
            return DragStartHelper.this.onTouch(view, motionEvent);
        }
    };
    private final View mView;

    public interface OnDragStartListener {
        boolean onDragStart();
    }

    public DragStartHelper(View view, OnDragStartListener onDragStartListener) {
        this.mView = view;
        this.mListener = onDragStartListener;
    }

    public void attach() {
        this.mView.setOnLongClickListener(this.mLongClickListener);
        this.mView.setOnTouchListener(this.mTouchListener);
    }

    public void detach() {
        this.mView.setOnLongClickListener(null);
        this.mView.setOnTouchListener(null);
    }

    public void getTouchPosition(Point point) {
        point.set(this.mLastTouchX, this.mLastTouchY);
    }

    public boolean onLongClick(View view) {
        return this.mListener.onDragStart();
    }

    /* JADX WARN: Code restructure failed: missing block: B:8:0x0018, code lost:
    
        if (r1 != 3) goto L28;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean onTouch(android.view.View r6, android.view.MotionEvent r7) {
        /*
            r5 = this;
            float r6 = r7.getX()
            int r6 = (int) r6
            float r0 = r7.getY()
            int r0 = (int) r0
            int r1 = r7.getAction()
            r2 = 0
            if (r1 == 0) goto L49
            r3 = 1
            if (r1 == r3) goto L46
            r4 = 2
            if (r1 == r4) goto L1b
            r6 = 3
            if (r1 == r6) goto L46
            goto L4d
        L1b:
            r1 = 8194(0x2002, float:1.1482E-41)
            boolean r1 = android.support.v4.view.MotionEventCompat.isFromSource(r7, r1)
            if (r1 == 0) goto L4d
            int r7 = r7.getButtonState()
            r7 = r7 & r3
            if (r7 != 0) goto L2b
            goto L4d
        L2b:
            boolean r7 = r5.mDragging
            if (r7 == 0) goto L30
            goto L4d
        L30:
            int r7 = r5.mLastTouchX
            if (r7 != r6) goto L39
            int r7 = r5.mLastTouchY
            if (r7 != r0) goto L39
            goto L4d
        L39:
            r5.mLastTouchX = r6
            r5.mLastTouchY = r0
            android.support.v13.view.DragStartHelper$OnDragStartListener r6 = r5.mListener
            boolean r6 = r6.onDragStart()
            r5.mDragging = r6
            return r6
        L46:
            r5.mDragging = r2
            goto L4d
        L49:
            r5.mLastTouchX = r6
            r5.mLastTouchY = r0
        L4d:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v13.view.DragStartHelper.onTouch(android.view.View, android.view.MotionEvent):boolean");
    }
}
