package crc648039626f5cedb2c4;

import android.os.Bundle;
import crc64da6839f08fe39125.EngineActivity;
import java.util.ArrayList;
import mono.android.Runtime;
import mono.android.TypeManager;

/* loaded from: classes.dex */
public class MainActivity extends EngineActivity {
    public static final String __md_methods = "n_onCreate:(Landroid/os/Bundle;)V:GetOnCreate_Landroid_os_Bundle_Handler\nn_onPause:()V:GetOnPauseHandler\nn_onResume:()V:GetOnResumeHandler\nn_onRequestPermissionsResult:(I[Ljava/lang/String;[I)V:GetOnRequestPermissionsResult_IarrayLjava_lang_String_arrayIHandler\n";
    private ArrayList refList;

    static {
        Runtime.register("SC.MainActivity, SC.Android", MainActivity.class, __md_methods);
    }

    public MainActivity() {
        if (getClass() == MainActivity.class) {
            TypeManager.Activate("SC.MainActivity, SC.Android", "", this, new Object[0]);
        }
    }

    private native void n_onCreate(Bundle bundle);

    private native void n_onPause();

    private native void n_onRequestPermissionsResult(int i, String[] strArr, int[] iArr);

    private native void n_onResume();

    @Override // crc64da6839f08fe39125.EngineActivity, mono.android.IGCUserPeer
    public void monodroidAddReference(Object obj) {
        if (this.refList == null) {
            this.refList = new ArrayList();
        }
        this.refList.add(obj);
    }

    @Override // crc64da6839f08fe39125.EngineActivity, mono.android.IGCUserPeer
    public void monodroidClearReferences() {
        ArrayList arrayList = this.refList;
        if (arrayList != null) {
            arrayList.clear();
        }
    }

    @Override // crc64da6839f08fe39125.EngineActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        n_onCreate(bundle);
    }

    @Override // crc64da6839f08fe39125.EngineActivity, android.app.Activity
    public void onPause() {
        n_onPause();
    }

    @Override // android.app.Activity
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        n_onRequestPermissionsResult(i, strArr, iArr);
    }

    @Override // crc64da6839f08fe39125.EngineActivity, android.app.Activity
    public void onResume() {
        n_onResume();
    }
}
