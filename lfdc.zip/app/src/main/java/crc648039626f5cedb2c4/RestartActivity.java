package crc648039626f5cedb2c4;

import android.app.Activity;
import android.os.Bundle;
import java.util.ArrayList;
import mono.android.IGCUserPeer;
import mono.android.Runtime;
import mono.android.TypeManager;

/* loaded from: classes.dex */
public class RestartActivity extends Activity implements IGCUserPeer {
    public static final String __md_methods = "n_onCreate:(Landroid/os/Bundle;)V:GetOnCreate_Landroid_os_Bundle_Handler\nn_onPause:()V:GetOnPauseHandler\nn_onResume:()V:GetOnResumeHandler\n";
    private ArrayList refList;

    static {
        Runtime.register("SC.RestartActivity, SC.Android", RestartActivity.class, __md_methods);
    }

    public RestartActivity() {
        if (getClass() == RestartActivity.class) {
            TypeManager.Activate("SC.RestartActivity, SC.Android", "", this, new Object[0]);
        }
    }

    private native void n_onCreate(Bundle bundle);

    private native void n_onPause();

    private native void n_onResume();

    @Override // mono.android.IGCUserPeer
    public void monodroidAddReference(Object obj) {
        if (this.refList == null) {
            this.refList = new ArrayList();
        }
        this.refList.add(obj);
    }

    @Override // mono.android.IGCUserPeer
    public void monodroidClearReferences() {
        ArrayList arrayList = this.refList;
        if (arrayList != null) {
            arrayList.clear();
        }
    }

    @Override // android.app.Activity
    public void onCreate(Bundle bundle) {
        n_onCreate(bundle);
    }

    @Override // android.app.Activity
    public void onPause() {
        n_onPause();
    }

    @Override // android.app.Activity
    public void onResume() {
        n_onResume();
    }
}
