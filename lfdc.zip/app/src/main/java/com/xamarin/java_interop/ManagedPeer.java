package com.xamarin.java_interop;

/* loaded from: classes.dex */
public final class ManagedPeer {
    private ManagedPeer() {
    }

    public static native void construct(Object obj, String str, String str2, Object... objArr);

    public static native void registerNativeMembers(Class cls, String str, String str2);
}
