package com.xamarin.java_interop;

/* loaded from: classes.dex */
public interface GCUserPeerable {
    void jiAddManagedReference(Object obj);

    void jiClearManagedReferences();
}
