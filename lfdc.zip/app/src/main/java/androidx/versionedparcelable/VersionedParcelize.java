package androidx.versionedparcelable;

import android.support.annotation.RestrictTo;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/* JADX WARN: Method from annotation default annotation not found: allowSerialization */
/* JADX WARN: Method from annotation default annotation not found: deprecatedIds */
/* JADX WARN: Method from annotation default annotation not found: ignoreParcelables */
/* JADX WARN: Method from annotation default annotation not found: isCustom */
/* JADX WARN: Method from annotation default annotation not found: jetifyAs */
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.SOURCE)
@RestrictTo
/* loaded from: classes.dex */
public @interface VersionedParcelize {
}
