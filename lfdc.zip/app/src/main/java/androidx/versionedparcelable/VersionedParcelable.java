package androidx.versionedparcelable;

import android.support.annotation.RestrictTo;

@RestrictTo
/* loaded from: classes.dex */
public interface VersionedParcelable {
}
