package mono.android;

/* loaded from: classes.dex */
public interface IGCUserPeer {
    void monodroidAddReference(Object obj);

    void monodroidClearReferences();
}
