package mono.android.app;

/* loaded from: classes.dex */
public class ApplicationRegistration {
    public static void registerApplications() {
    }
}
