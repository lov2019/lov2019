package mono.android;

/* loaded from: classes.dex */
public class DebugRuntime {
    private DebugRuntime() {
    }

    public static native void init(String[] strArr, String str, String[] strArr2, boolean z);
}
