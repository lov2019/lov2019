package mono.android;

/* loaded from: classes.dex */
public class BuildConfig {
    public static boolean Debug = false;
    public static boolean DotNetRuntime = false;
}
